from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.middleware.csrf import get_token
from rest_framework import filters, mixins, status, viewsets
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from rest_framework.views import APIView

from config.exceptions import BusinessError

from .models import PatientProfile, Role, User
from .permissions import IsAdminRole, IsPatient
from .serializers import (AdminPatientSerializer, ChangePasswordSerializer, LoginSerializer,
                          PatientProfileSerializer, RegisterSerializer, UserSerializer)


class CsrfView(APIView):
    """Sets the csrftoken cookie so React can send it back in the X-CSRFToken header."""
    permission_classes = [AllowAny]

    def get(self, request):
        return Response({"csrfToken": get_token(request)})


class RegisterView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "auth"

    def post(self, request):
        s = RegisterSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        user = s.save()
        login(request, user)
        return Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)


class LoginView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "auth"

    def post(self, request):
        s = LoginSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        identifier = s.validated_data["email"].strip().lower()
        # "email or username": we use the email as the username
        user = authenticate(request, username=identifier, password=s.validated_data["password"])
        if user is None:
            raise BusinessError("invalid_credentials", "Incorrect email or password.", status.HTTP_401_UNAUTHORIZED)
        login(request, user)
        return Response(UserSerializer(user).data)


class LogoutView(APIView):
    def post(self, request):
        logout(request)
        return Response(status=status.HTTP_204_NO_CONTENT)


class MeView(APIView):
    def get(self, request):
        return Response(UserSerializer(request.user).data)


class ChangePasswordView(APIView):
    def post(self, request):
        s = ChangePasswordSerializer(data=request.data, context={"request": request})
        s.is_valid(raise_exception=True)
        request.user.set_password(s.validated_data["new_password"])
        request.user.save()
        update_session_auth_hash(request, request.user)  # keep the user logged in
        return Response({"message": "Password updated."})


class PatientMeView(APIView):
    permission_classes = [IsPatient]

    def _profile(self, request):
        profile, _ = PatientProfile.objects.get_or_create(user=request.user)
        return profile

    def get(self, request):
        return Response(PatientProfileSerializer(self._profile(request)).data)

    def patch(self, request):
        s = PatientProfileSerializer(self._profile(request), data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return Response(s.data)


class AdminPatientViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, mixins.UpdateModelMixin,
                          viewsets.GenericViewSet):
    """Admin: list/search patients and activate/deactivate accounts (PATCH is_active)."""
    permission_classes = [IsAdminRole]
    serializer_class = AdminPatientSerializer
    queryset = User.objects.filter(role=Role.PATIENT).order_by("-created_at")
    filter_backends = [filters.SearchFilter]
    search_fields = ["name", "email", "phone"]
    http_method_names = ["get", "patch", "head", "options"]
