from rest_framework.permissions import BasePermission

from .models import Role


class _RolePermission(BasePermission):
    role = None

    def has_permission(self, request, view):
        u = request.user
        return bool(u and u.is_authenticated and u.is_active and u.role == self.role)


class IsPatient(_RolePermission):
    role = Role.PATIENT


class IsDoctor(_RolePermission):
    role = Role.DOCTOR


class IsAdminRole(_RolePermission):
    role = Role.ADMIN
