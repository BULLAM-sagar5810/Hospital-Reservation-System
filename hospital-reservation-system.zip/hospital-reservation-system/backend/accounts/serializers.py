from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from .models import PatientProfile, Role

User = get_user_model()


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, style={"input_type": "password"})
    confirm_password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ["name", "email", "phone", "password", "confirm_password"]

    def validate_email(self, value):
        value = value.lower()
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("An account with this email already exists.")
        return value

    def validate_phone(self, value):
        digits = value.replace(" ", "").replace("-", "").lstrip("+")
        if value and (not digits.isdigit() or not 7 <= len(digits) <= 15):
            raise serializers.ValidationError("Enter a valid phone number.")
        return value

    def validate(self, attrs):
        if attrs["password"] != attrs.pop("confirm_password"):
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})
        validate_password(attrs["password"], User(name=attrs["name"], email=attrs["email"]))
        return attrs

    def create(self, validated_data):
        user = User.objects.create_user(role=Role.PATIENT, **validated_data)
        PatientProfile.objects.create(user=user)
        return user


class LoginSerializer(serializers.Serializer):
    email = serializers.CharField()
    password = serializers.CharField(write_only=True)


class UserSerializer(serializers.ModelSerializer):
    doctor_profile_id = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ["id", "name", "email", "phone", "role", "doctor_profile_id"]

    def get_doctor_profile_id(self, obj):
        profile = getattr(obj, "doctor_profile", None)
        return profile.id if profile else None


class PatientProfileSerializer(serializers.ModelSerializer):
    name = serializers.CharField(source="user.name")
    email = serializers.EmailField(source="user.email", read_only=True)
    phone = serializers.CharField(source="user.phone", required=False, allow_blank=True)

    class Meta:
        model = PatientProfile
        fields = ["id", "name", "email", "phone", "date_of_birth", "address"]

    def update(self, instance, validated_data):
        user_data = validated_data.pop("user", {})
        for k, v in user_data.items():
            setattr(instance.user, k, v)
        if user_data:
            instance.user.save()
        return super().update(instance, validated_data)


class AdminPatientSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "name", "email", "phone", "is_active", "created_at"]
        read_only_fields = ["id", "name", "email", "phone", "created_at"]


class ChangePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField(write_only=True)
    new_password = serializers.CharField(write_only=True)

    def validate_current_password(self, value):
        if not self.context["request"].user.check_password(value):
            raise serializers.ValidationError("Current password is incorrect.")
        return value

    def validate_new_password(self, value):
        validate_password(value, self.context["request"].user)
        return value
