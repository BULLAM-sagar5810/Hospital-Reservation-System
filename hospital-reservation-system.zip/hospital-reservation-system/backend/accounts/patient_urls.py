from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import AdminPatientViewSet, PatientMeView

router = DefaultRouter()
router.register("", AdminPatientViewSet, basename="patient")

# "me/" must be listed before the router so it is not read as a patient id
urlpatterns = [path("me/", PatientMeView.as_view())] + router.urls
