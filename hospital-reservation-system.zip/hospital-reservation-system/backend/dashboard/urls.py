from django.urls import path

from . import views

urlpatterns = [
    path("patient/", views.PatientDashboard.as_view()),
    path("doctor/", views.DoctorDashboard.as_view()),
    path("admin/", views.AdminDashboard.as_view()),
]
