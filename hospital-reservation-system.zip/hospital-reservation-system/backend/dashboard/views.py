from django.db.models import Count, F
from django.utils import timezone
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.models import Role, User
from accounts.permissions import IsAdminRole, IsDoctor, IsPatient
from appointments.models import ACTIVE_STATUSES, Appointment, Status
from appointments.serializers import AppointmentSerializer
from departments.models import Department
from doctors.models import DoctorProfile, DoctorSchedule


def _status_counts(qs):
    counts = {s: 0 for s in Status.values}
    counts.update({r["status"]: r["n"] for r in qs.values("status").annotate(n=Count("id"))})
    return counts


class PatientDashboard(APIView):
    permission_classes = [IsPatient]

    def get(self, request):
        now = timezone.now()
        base = Appointment.objects.filter(patient=request.user).select_related(
            "doctor__user", "doctor__department", "patient")
        ctx = {"request": request}
        ser = lambda qs: AppointmentSerializer(qs, many=True, context=ctx).data
        upcoming = base.filter(start_datetime__gte=now, status__in=ACTIVE_STATUSES).order_by("start_datetime")
        previous = base.filter(status__in=[Status.COMPLETED, Status.NO_SHOW, Status.REJECTED]).order_by("-start_datetime")
        cancelled = base.filter(status=Status.CANCELLED).order_by("-start_datetime")
        return Response({"stats": _status_counts(base) | {"TOTAL": base.count(), "UPCOMING": upcoming.count()},
                         "upcoming": ser(upcoming[:5]), "previous": ser(previous[:5]), "cancelled": ser(cancelled[:5])})


class DoctorDashboard(APIView):
    permission_classes = [IsDoctor]

    def get(self, request):
        doctor = request.user.doctor_profile
        now = timezone.now()
        today = timezone.localdate()
        base = Appointment.objects.filter(doctor=doctor).select_related("doctor__user", "doctor__department", "patient")
        ctx = {"request": request}
        ser = lambda qs: AppointmentSerializer(qs, many=True, context=ctx).data
        today_qs = base.filter(start_datetime__date=today).exclude(status__in=[Status.CANCELLED, Status.REJECTED]) \
            .order_by("start_datetime")
        upcoming = base.filter(start_datetime__date__gt=today, status__in=ACTIVE_STATUSES).order_by("start_datetime")[:10]
        schedule = list(DoctorSchedule.objects.filter(doctor=doctor, is_active=True)
                        .values("id", "day_of_week", "start_time", "end_time", "slot_duration_minutes"))
        return Response({"today": ser(today_qs), "upcoming": ser(upcoming), "stats": _status_counts(base),
                         "pending_requests": base.filter(status=Status.PENDING).count(), "schedule": schedule,
                         "is_accepting_appointments": doctor.is_accepting_appointments})


class AdminDashboard(APIView):
    permission_classes = [IsAdminRole]

    def get(self, request):
        base = Appointment.objects.all()
        counts = _status_counts(base)
        recent = base.select_related("doctor__user", "doctor__department", "patient").order_by("-created_at")[:8]
        by_dept = (base.values(name=F("doctor__department__name"))
                   .annotate(total=Count("id")).order_by("-total"))
        top = (base.values(name=F("doctor__user__name"))
               .annotate(total=Count("id")).order_by("-total")[:5])
        total = base.count()
        return Response({
            "total_patients": User.objects.filter(role=Role.PATIENT).count(),
            "total_active_doctors": DoctorProfile.objects.filter(is_listed=True, user__is_active=True).count(),
            "total_departments": Department.objects.filter(is_active=True).count(),
            "total_appointments": total,
            "pending_appointments": counts[Status.PENDING],
            "cancelled_appointments": counts[Status.CANCELLED],
            "cancellation_rate": round(counts[Status.CANCELLED] * 100 / total, 1) if total else 0,
            "status_counts": counts,
            "by_department": list(by_dept),
            "top_doctors": list(top),
            "recent": AppointmentSerializer(recent, many=True, context={"request": request}).data,
        })
