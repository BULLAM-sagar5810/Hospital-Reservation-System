"""All booking rules live here, so views stay thin and every rule is enforced on the server."""
from datetime import datetime, timedelta

from django.conf import settings
from django.core.mail import send_mail
from django.db import IntegrityError, transaction
from django.utils import timezone

from accounts.models import Role
from config.exceptions import BusinessError
from doctors.models import DoctorProfile, DoctorTimeOff

from .models import ACTIVE_STATUSES, Appointment, Notification, Status


# ------------------------------------------------------------------ helpers
def local_tz():
    return timezone.get_current_timezone()


def _aware(d, t):
    return timezone.make_aware(datetime.combine(d, t), local_tz())


def day_slots(doctor, day):
    """Every bookable slot on `day` according to the weekly schedule (ignores bookings / leave / past)."""
    slots = []
    for sch in doctor.schedules.filter(is_active=True, day_of_week=day.weekday()):
        step = timedelta(minutes=sch.slot_duration_minutes)
        cur, end = _aware(day, sch.start_time), _aware(day, sch.end_time)
        while cur + step <= end:
            slots.append((cur, cur + step))
            cur += step
    return sorted(slots)


def _overlaps(a_start, a_end, b_start, b_end):
    return a_start < b_end and a_end > b_start


def available_slots(doctor, day):
    """Slots that are in the future, not on leave and not already taken."""
    now = timezone.now()
    today = timezone.localdate()
    if not doctor.is_accepting_appointments or not doctor.is_listed or not doctor.user.is_active:
        return []
    if day < today or day > today + timedelta(days=settings.BOOKING_MAX_DAYS_AHEAD):
        return []
    grid = day_slots(doctor, day)
    if not grid:
        return []
    lo, hi = grid[0][0], grid[-1][1]
    taken = list(Appointment.objects.filter(doctor=doctor, status__in=ACTIVE_STATUSES,
                                            start_datetime__lt=hi, end_datetime__gt=lo)
                 .values_list("start_datetime", "end_datetime"))
    off = list(DoctorTimeOff.objects.filter(doctor=doctor, start_datetime__lt=hi, end_datetime__gt=lo)
               .values_list("start_datetime", "end_datetime"))
    return [(s, e) for s, e in grid
            if s > now and not any(_overlaps(s, e, a, b) for a, b in taken + off)]


def validate_slot(doctor, start, exclude=None):
    """Raises BusinessError unless `start` is a free, valid slot. Returns the slot end time."""
    if doctor.user.is_active is False or not doctor.is_listed:
        raise BusinessError("doctor_not_found", "Doctor not found.", 404)
    if not doctor.is_accepting_appointments:
        raise BusinessError("doctor_not_accepting", "This doctor is not accepting appointments right now.", 409)
    now = timezone.now()
    if start <= now:
        raise BusinessError("invalid_date", "The appointment time is in the past.")
    local_start = timezone.localtime(start)
    if local_start.date() > timezone.localdate() + timedelta(days=settings.BOOKING_MAX_DAYS_AHEAD):
        raise BusinessError("invalid_date",
                            f"Appointments can only be booked {settings.BOOKING_MAX_DAYS_AHEAD} days ahead.")
    match = [e for s, e in day_slots(doctor, local_start.date()) if s == start]
    if not match:
        raise BusinessError("invalid_slot", "This time is not one of the doctor's scheduled slots.")
    end = match[0]
    if DoctorTimeOff.objects.filter(doctor=doctor, start_datetime__lt=end, end_datetime__gt=start).exists():
        raise BusinessError("slot_unavailable", "The doctor is unavailable at this time.", 409)
    clash = Appointment.objects.filter(doctor=doctor, status__in=ACTIVE_STATUSES,
                                       start_datetime__lt=end, end_datetime__gt=start)
    if exclude:
        clash = clash.exclude(pk=exclude.pk)
    if clash.exists():
        raise BusinessError("slot_unavailable", "This slot has just been booked. Please choose another.", 409)
    return end


def _check_patient_free(patient, start, end, exclude=None):
    qs = Appointment.objects.filter(patient=patient, status__in=ACTIVE_STATUSES,
                                    start_datetime__lt=end, end_datetime__gt=start)
    if exclude:
        qs = qs.exclude(pk=exclude.pk)
    if qs.exists():
        raise BusinessError("duplicate_booking", "You already have an appointment at this time.", 409)


def _fmt(dt):
    return timezone.localtime(dt).strftime("%d %b %Y, %I:%M %p")


def notify(user, appointment, message):
    Notification.objects.create(user=user, appointment=appointment, message=message)
    if user.email:
        send_mail("Hospital appointment update", message, None, [user.email], fail_silently=True)


# ------------------------------------------------------------------ actions
def book(patient, doctor_id, start, reason=""):
    with transaction.atomic():
        # Lock the doctor's row: concurrent bookings for this doctor are processed one at a time.
        doctor = DoctorProfile.objects.select_for_update().filter(pk=doctor_id).first()
        if doctor is None:
            raise BusinessError("doctor_not_found", "Doctor not found.", 404)
        doctor = DoctorProfile.objects.select_related("user", "department").get(pk=doctor.pk)
        end = validate_slot(doctor, start)
        _check_patient_free(patient, start, end)
        status = Status.CONFIRMED if settings.APPOINTMENT_AUTO_CONFIRM else Status.PENDING
        try:
            with transaction.atomic():
                appt = Appointment.objects.create(patient=patient, doctor=doctor, start_datetime=start,
                                                  end_datetime=end, reason_for_visit=reason, status=status)
        except IntegrityError:  # the UNIQUE constraint is the last line of defence
            raise BusinessError("slot_unavailable", "This slot has just been booked. Please choose another.", 409)
        word = "confirmed" if status == Status.CONFIRMED else "received and awaiting the doctor's confirmation"
        notify(patient, appt, f"Your appointment #{appt.pk} with {doctor} on {_fmt(start)} is {word}.")
        if status == Status.PENDING:
            notify(doctor.user, appt, f"New appointment request #{appt.pk} for {_fmt(start)}.")
    return appt


def _window_check(appt, user):
    if user.role == Role.PATIENT:
        limit = timezone.now() + timedelta(hours=settings.CANCELLATION_MIN_HOURS)
        if appt.start_datetime < limit:
            raise BusinessError("change_window_closed",
                                f"Appointments can only be changed at least {settings.CANCELLATION_MIN_HOURS} "
                                "hours before the start time.", 409)


def cancel(appt_id, user, reason=""):
    with transaction.atomic():
        appt = Appointment.objects.select_for_update().get(pk=appt_id)
        if appt.status not in ACTIVE_STATUSES:
            raise BusinessError("not_cancellable", f"A {appt.status.lower()} appointment cannot be cancelled.", 409)
        _window_check(appt, user)
        appt.status = Status.CANCELLED
        appt.cancellation_reason = reason[:255]
        appt.save()  # active_start becomes NULL, so the slot is free again
        if user.role != Role.DOCTOR:
            notify(appt.doctor.user, appt, f"Appointment #{appt.pk} on {_fmt(appt.start_datetime)} was cancelled.")
        if user.role != Role.PATIENT:
            notify(appt.patient, appt, f"Your appointment #{appt.pk} on {_fmt(appt.start_datetime)} was cancelled.")
    return appt


def reschedule(appt_id, user, new_start):
    with transaction.atomic():
        appt = Appointment.objects.select_for_update().get(pk=appt_id)
        if appt.status not in ACTIVE_STATUSES:
            raise BusinessError("not_reschedulable", f"A {appt.status.lower()} appointment cannot be rescheduled.", 409)
        _window_check(appt, user)
        DoctorProfile.objects.select_for_update().get(pk=appt.doctor_id)
        doctor = DoctorProfile.objects.select_related("user", "department").get(pk=appt.doctor_id)
        end = validate_slot(doctor, new_start, exclude=appt)
        _check_patient_free(appt.patient, new_start, end, exclude=appt)
        old = appt.start_datetime
        appt.start_datetime, appt.end_datetime = new_start, end
        appt.status = Status.CONFIRMED if settings.APPOINTMENT_AUTO_CONFIRM else Status.PENDING
        try:
            with transaction.atomic():
                appt.save()
        except IntegrityError:
            raise BusinessError("slot_unavailable", "This slot has just been booked. Please choose another.", 409)
        notify(appt.patient, appt, f"Appointment #{appt.pk} moved from {_fmt(old)} to {_fmt(new_start)}.")
        notify(doctor.user, appt, f"Appointment #{appt.pk} was rescheduled to {_fmt(new_start)}.")
    return appt


ALLOWED_TRANSITIONS = {
    Status.PENDING: {Status.CONFIRMED, Status.REJECTED, Status.CANCELLED},
    Status.CONFIRMED: {Status.COMPLETED, Status.NO_SHOW, Status.CANCELLED},
}


def set_status(appt_id, user, new_status, reason=""):
    """Doctor / admin status changes."""
    with transaction.atomic():
        appt = Appointment.objects.select_for_update().get(pk=appt_id)
        if new_status not in ALLOWED_TRANSITIONS.get(appt.status, set()):
            raise BusinessError("invalid_transition",
                                f"Cannot change status from {appt.status} to {new_status}.", 409)
        if new_status in (Status.COMPLETED, Status.NO_SHOW) and appt.start_datetime > timezone.now():
            raise BusinessError("too_early", "This appointment has not started yet.", 409)
        appt.status = new_status
        if new_status in (Status.CANCELLED, Status.REJECTED):
            appt.cancellation_reason = reason[:255]
        appt.save()
        notify(appt.patient, appt,
               f"Appointment #{appt.pk} on {_fmt(appt.start_datetime)} is now {new_status.replace('_', ' ').lower()}.")
    return appt
