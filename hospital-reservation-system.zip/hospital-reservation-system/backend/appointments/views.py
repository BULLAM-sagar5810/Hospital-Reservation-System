from datetime import date as date_cls

from django.db.models import Q
from django.utils import timezone
from rest_framework import mixins, status as http, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle

from accounts.models import Role
from accounts.permissions import IsPatient
from config.exceptions import BusinessError

from . import services
from .models import ACTIVE_STATUSES, Appointment, Notification, Status
from .serializers import (AppointmentCreateSerializer, AppointmentSerializer, AppointmentUpdateSerializer,
                          CancelSerializer, NotificationSerializer, RescheduleSerializer)


class AppointmentViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    serializer_class = AppointmentSerializer
    permission_classes = [IsAuthenticated]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "booking"

    # -- object level isolation: the queryset itself only contains rows the user may see,
    #    so someone else's appointment simply answers 404.
    def get_queryset(self):
        u, p = self.request.user, self.request.query_params
        qs = Appointment.objects.select_related("doctor__user", "doctor__department", "patient")
        if u.role == Role.PATIENT:
            qs = qs.filter(patient=u)
        elif u.role == Role.DOCTOR:
            qs = qs.filter(doctor__user=u)
        elif u.role != Role.ADMIN:
            return qs.none()

        if p.get("status") in Status.values:
            qs = qs.filter(status=p["status"])
        if p.get("date"):
            try:
                d = date_cls.fromisoformat(p["date"])
            except ValueError:
                raise BusinessError("invalid_date", "Use YYYY-MM-DD for the date filter.")
            qs = qs.filter(start_datetime__date=d)  # converted using the current time zone
        if p.get("doctor", "").isdigit():
            qs = qs.filter(doctor_id=int(p["doctor"]))
        if p.get("search") and u.role == Role.ADMIN:
            term = p["search"].strip()
            cond = Q(patient__name__icontains=term) | Q(doctor__user__name__icontains=term)
            if term.isdigit():
                cond |= Q(pk=int(term))
            qs = qs.filter(cond)
        if p.get("upcoming") == "true":
            return qs.filter(start_datetime__gte=timezone.now(), status__in=ACTIVE_STATUSES).order_by("start_datetime")
        if p.get("history") == "true":
            qs = qs.exclude(start_datetime__gte=timezone.now(), status__in=ACTIVE_STATUSES)
        return qs.order_by("-start_datetime")

    def create(self, request):
        if request.user.role != Role.PATIENT:
            raise BusinessError("forbidden", "Only patients can book appointments.", 403)
        s = AppointmentCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        appt = services.book(request.user, d["doctor_id"], d["start_datetime"], d["reason_for_visit"])
        return Response(self._out(appt), status=http.HTTP_201_CREATED)

    def partial_update(self, request, pk=None):
        appt = self.get_object()
        s = AppointmentUpdateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        role = request.user.role
        if "reason_for_visit" in d:
            if role != Role.PATIENT or appt.status not in ACTIVE_STATUSES:
                raise BusinessError("forbidden", "Only the patient can edit the reason of an active appointment.", 403)
            appt.reason_for_visit = d["reason_for_visit"]
            appt.save(update_fields=["reason_for_visit", "updated_at"])
        if "status" in d:
            if role == Role.PATIENT:
                raise BusinessError("forbidden", "Patients can only use the cancel endpoint.", 403)
            appt = services.set_status(appt.pk, request.user, d["status"], d.get("cancellation_reason", ""))
        return Response(self._out(appt))

    def _out(self, appt):
        appt = Appointment.objects.select_related("doctor__user", "doctor__department", "patient").get(pk=appt.pk)
        return AppointmentSerializer(appt, context=self.get_serializer_context()).data

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        appt = self.get_object()
        s = CancelSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        appt = services.cancel(appt.pk, request.user, s.validated_data["reason"])
        return Response(self._out(appt))

    @action(detail=True, methods=["post"])
    def reschedule(self, request, pk=None):
        appt = self.get_object()
        if request.user.role == Role.DOCTOR:
            raise BusinessError("forbidden", "Doctors cannot reschedule patient bookings.", 403)
        s = RescheduleSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        appt = services.reschedule(appt.pk, request.user, s.validated_data["start_datetime"])
        return Response(self._out(appt))


class NotificationViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)

    @action(detail=True, methods=["post"])
    def read(self, request, pk=None):
        n = self.get_object()
        n.is_read = True
        n.save(update_fields=["is_read"])
        return Response(NotificationSerializer(n).data)

    @action(detail=False, methods=["post"], url_path="read-all")
    def read_all(self, request):
        self.get_queryset().filter(is_read=False).update(is_read=True)
        return Response({"message": "All notifications marked as read."})
