from rest_framework.routers import DefaultRouter

from .views import AppointmentViewSet, NotificationViewSet

router = DefaultRouter()
router.register("appointments", AppointmentViewSet, basename="appointment")
router.register("notifications", NotificationViewSet, basename="notification")
urlpatterns = router.urls
