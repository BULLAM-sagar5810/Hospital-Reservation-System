from datetime import timedelta

from django.conf import settings
from django.utils import timezone
from rest_framework import serializers

from accounts.models import Role

from .models import ACTIVE_STATUSES, Appointment, Notification, Status


class AppointmentSerializer(serializers.ModelSerializer):
    """Output shape. Patient details are minimised depending on who is asking."""
    doctor_id = serializers.IntegerField(read_only=True)
    doctor_name = serializers.CharField(source="doctor.user.name", read_only=True)
    department = serializers.CharField(source="doctor.department.name", read_only=True)
    specialization = serializers.CharField(source="doctor.specialization", read_only=True)
    can_cancel = serializers.SerializerMethodField()
    can_reschedule = serializers.SerializerMethodField()

    class Meta:
        model = Appointment
        fields = ["id", "doctor_id", "doctor_name", "department", "specialization", "start_datetime",
                  "end_datetime", "reason_for_visit", "status", "cancellation_reason", "created_at",
                  "can_cancel", "can_reschedule"]

    def _changeable(self, obj):
        user = self.context["request"].user
        if obj.status not in ACTIVE_STATUSES:
            return False
        if user.role == Role.PATIENT:
            return obj.start_datetime >= timezone.now() + timedelta(hours=settings.CANCELLATION_MIN_HOURS)
        return True

    def get_can_cancel(self, obj):
        return self._changeable(obj)

    def get_can_reschedule(self, obj):
        return self._changeable(obj) and self.context["request"].user.role != Role.DOCTOR

    def to_representation(self, obj):
        data = super().to_representation(obj)
        role = self.context["request"].user.role
        if role == Role.DOCTOR:  # minimum necessary: name only
            data["patient_name"] = obj.patient.name
        elif role == Role.ADMIN:
            data.update(patient_id=obj.patient_id, patient_name=obj.patient.name,
                        patient_email=obj.patient.email, patient_phone=obj.patient.phone)
        return data


class AppointmentCreateSerializer(serializers.Serializer):
    doctor_id = serializers.IntegerField()
    start_datetime = serializers.DateTimeField()
    reason_for_visit = serializers.CharField(max_length=500, required=False, allow_blank=True, default="")


class RescheduleSerializer(serializers.Serializer):
    start_datetime = serializers.DateTimeField()


class CancelSerializer(serializers.Serializer):
    reason = serializers.CharField(max_length=255, required=False, allow_blank=True, default="")


class AppointmentUpdateSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=Status.choices, required=False)
    reason_for_visit = serializers.CharField(max_length=500, required=False, allow_blank=True)
    cancellation_reason = serializers.CharField(max_length=255, required=False, allow_blank=True)


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ["id", "appointment", "message", "is_read", "created_at"]
