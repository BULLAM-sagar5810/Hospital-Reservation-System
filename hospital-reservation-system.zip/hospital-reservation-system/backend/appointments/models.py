from django.conf import settings
from django.db import models

from doctors.models import DoctorProfile


class Status(models.TextChoices):
    PENDING = "PENDING", "Pending"
    CONFIRMED = "CONFIRMED", "Confirmed"
    CANCELLED = "CANCELLED", "Cancelled"
    COMPLETED = "COMPLETED", "Completed"
    NO_SHOW = "NO_SHOW", "No show"
    REJECTED = "REJECTED", "Rejected"


ACTIVE_STATUSES = (Status.PENDING, Status.CONFIRMED)  # these block a time slot


class Appointment(models.Model):
    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="appointments")
    doctor = models.ForeignKey(DoctorProfile, on_delete=models.PROTECT, related_name="appointments")
    start_datetime = models.DateTimeField()
    end_datetime = models.DateTimeField()
    reason_for_visit = models.CharField(max_length=500, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    cancellation_reason = models.CharField(max_length=255, blank=True)
    # Database level double-booking guard. It equals start_datetime while the appointment is active
    # and NULL otherwise. MySQL allows many NULLs in a UNIQUE index, so cancelled slots can be re-booked
    # while two ACTIVE bookings of the same slot are rejected by the database itself.
    active_start = models.DateTimeField(null=True, blank=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-start_datetime"]
        constraints = [models.UniqueConstraint(fields=["doctor", "active_start"], name="uniq_active_slot_per_doctor")]
        indexes = [
            models.Index(fields=["doctor", "start_datetime"]),
            models.Index(fields=["patient", "start_datetime"]),
            models.Index(fields=["status"]),
        ]

    def save(self, *args, **kwargs):
        self.active_start = self.start_datetime if self.status in ACTIVE_STATUSES else None
        if kwargs.get("update_fields") is not None:
            kwargs["update_fields"] = set(kwargs["update_fields"]) | {"active_start"}
        super().save(*args, **kwargs)

    def __str__(self):
        return f"#{self.pk} {self.patient_id}->{self.doctor_id} {self.start_datetime:%Y-%m-%d %H:%M} {self.status}"


class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    appointment = models.ForeignKey(Appointment, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name="notifications")
    message = models.CharField(max_length=500)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["user", "is_read"])]
