from datetime import time

from rest_framework.test import APIClient

from accounts.models import Role, User
from doctors.models import DoctorSchedule, DoctorTimeOff

from .base import PASSWORD, BaseAPITest, slot_dt


class DoctorTests(BaseAPITest):
    def test_public_listing_hides_sensitive_fields_and_unlisted(self):
        self.doctor2.is_listed = False
        self.doctor2.save()
        r = APIClient().get("/api/doctors/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["count"], 1)
        self.assertNotIn("email", r.data["results"][0])
        self.assertNotIn("phone", r.data["results"][0])
        self.assertEqual(APIClient().get(f"/api/doctors/{self.doctor2.id}/").status_code, 404)
        admin_view = self.login(self.admin).get("/api/doctors/")
        self.assertEqual(admin_view.data["count"], 2)

    def test_search_and_department_filter(self):
        self.assertEqual(APIClient().get("/api/doctors/?search=doc one").data["count"], 1)
        self.assertEqual(APIClient().get("/api/doctors/?search=heart").data["count"], 1)
        self.assertEqual(APIClient().get("/api/doctors/?search=cardio").data["count"], 2)
        self.assertEqual(APIClient().get(f"/api/doctors/?department={self.dept.id + 99}").data["count"], 0)

    def test_admin_creates_doctor_and_others_cannot(self):
        body = {"new_name": "Dr New", "email": "new.doc@t.test", "password": PASSWORD,
                "department_id": self.dept.id, "specialization": "X", "consultation_fee": "300.00"}
        self.assertEqual(self.login(self.p1).post("/api/doctors/", body, format="json").status_code, 403)
        self.assertEqual(self.login(self.doc_user).post("/api/doctors/", body, format="json").status_code, 403)
        r = self.login(self.admin).post("/api/doctors/", body, format="json")
        self.assertEqual(r.status_code, 201)
        self.assertEqual(User.objects.get(email="new.doc@t.test").role, Role.DOCTOR)

    def test_doctor_edits_only_own_allowed_fields(self):
        c = self.login(self.doc_user)
        ok = c.patch(f"/api/doctors/{self.doctor.id}/", {"biography": "Hello"}, format="json")
        self.assertEqual(ok.status_code, 200)
        fee = c.patch(f"/api/doctors/{self.doctor.id}/", {"consultation_fee": "1"}, format="json")
        self.assertEqual(fee.status_code, 403)
        other = c.patch(f"/api/doctors/{self.doctor2.id}/", {"biography": "Hacked"}, format="json")
        self.assertEqual(other.status_code, 403)
        self.assertEqual(self.login(self.p1).patch(f"/api/doctors/{self.doctor.id}/", {"biography": "x"},
                                                   format="json").status_code, 403)

    def test_availability_endpoint(self):
        r = APIClient().get(f"/api/doctors/{self.doctor.id}/availability/?date={self.day.isoformat()}")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(len(r.data["slots"]), 6)  # 09:00-12:00 / 30 min
        self.assertEqual(APIClient().get(f"/api/doctors/{self.doctor.id}/availability/?date=bad").status_code, 400)

    def test_availability_respects_time_off_and_bookings(self):
        DoctorTimeOff.objects.create(doctor=self.doctor, start_datetime=slot_dt(self.day, 9),
                                     end_datetime=slot_dt(self.day, 10), reason="Meeting")
        self.book(self.login(self.p1), 11)
        r = APIClient().get(f"/api/doctors/{self.doctor.id}/availability/?date={self.day.isoformat()}")
        starts = [s["start"] for s in r.data["slots"]]
        self.assertEqual(len(starts), 6 - 2 - 1)
        self.assertNotIn(slot_dt(self.day, 11).isoformat(), starts)

    def test_no_slots_when_not_accepting(self):
        self.doctor.is_accepting_appointments = False
        self.doctor.save()
        r = APIClient().get(f"/api/doctors/{self.doctor.id}/availability/?date={self.day.isoformat()}")
        self.assertEqual(r.data["slots"], [])

    def test_schedule_management_scoped(self):
        c = self.login(self.doc_user)
        r = c.post("/api/schedules/", {"day_of_week": 5, "start_time": "09:00", "end_time": "11:00",
                                       "slot_duration_minutes": 20}, format="json")
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.data["doctor"], self.doctor.id)
        overlap = c.post("/api/schedules/", {"day_of_week": 5, "start_time": "10:00", "end_time": "12:00"},
                         format="json")
        self.assertEqual(overlap.status_code, 400)
        other = DoctorSchedule.objects.filter(doctor=self.doctor2).first()
        self.assertEqual(c.patch(f"/api/schedules/{other.id}/", {"is_active": False}, format="json").status_code, 404)
        self.assertEqual(self.login(self.p1).get("/api/schedules/").status_code, 403)
        self.assertEqual(self.login(self.admin).post("/api/schedules/", {
            "doctor": self.doctor2.id, "day_of_week": 6, "start_time": "09:00", "end_time": "10:00"},
            format="json").status_code, 201)

    def test_time_off_crud_for_doctor(self):
        c = self.login(self.doc_user)
        r = c.post("/api/time-off/", {"start_datetime": slot_dt(self.day, 9).isoformat(),
                                      "end_datetime": slot_dt(self.day, 13).isoformat(), "reason": "Leave"},
                   format="json")
        self.assertEqual(r.status_code, 201)
        bad = c.post("/api/time-off/", {"start_datetime": slot_dt(self.day, 9).isoformat(),
                                        "end_datetime": slot_dt(self.day, 8).isoformat()}, format="json")
        self.assertEqual(bad.status_code, 400)
        self.assertEqual(c.delete(f"/api/time-off/{r.data['id']}/").status_code, 204)
