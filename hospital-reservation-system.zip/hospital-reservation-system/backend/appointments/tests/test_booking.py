import threading
from datetime import timedelta

from django.db import connection
from django.test import TransactionTestCase
from django.utils import timezone

from accounts.models import Role
from appointments.models import Appointment, Notification, Status
from doctors.models import DoctorTimeOff

from .base import BaseAPITest, make_user, next_weekday, slot_dt


class BookingTests(BaseAPITest):
    def test_book_success_creates_confirmed_appointment_and_notification(self):
        r = self.book(self.login(self.p1))
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.data["status"], "CONFIRMED")
        self.assertEqual(r.data["doctor_name"], "Doc One")
        self.assertTrue(Notification.objects.filter(user=self.p1, appointment_id=r.data["id"]).exists())

    def test_only_patients_can_book(self):
        self.assertEqual(self.book(self.login(self.doc_user)).status_code, 403)
        self.assertEqual(self.book(self.login(self.admin)).status_code, 403)
        self.assertEqual(self.book(self.client).status_code, 403)

    def test_double_booking_is_rejected(self):
        self.assertEqual(self.book(self.login(self.p1)).status_code, 201)
        r = self.book(self.login(self.p2))
        self.assertEqual(r.status_code, 409)
        self.assertEqual(r.data["error"]["code"], "slot_unavailable")

    def test_same_patient_cannot_overlap_with_another_doctor(self):
        c = self.login(self.p1)
        self.assertEqual(self.book(c).status_code, 201)
        r = self.book(c, doctor=self.doctor2)
        self.assertEqual(r.status_code, 409)
        self.assertEqual(r.data["error"]["code"], "duplicate_booking")

    def test_past_date_rejected(self):
        past = timezone.localdate() - timedelta(days=7)
        r = self.book(self.login(self.p1), day=past)
        self.assertEqual(r.status_code, 400)
        self.assertEqual(r.data["error"]["code"], "invalid_date")

    def test_too_far_ahead_rejected(self):
        r = self.book(self.login(self.p1), day=next_weekday(0, min_days=100))
        self.assertEqual(r.data["error"]["code"], "invalid_date")

    def test_off_grid_time_and_weekend_rejected(self):
        c = self.login(self.p1)
        self.assertEqual(self.book(c, 10, 15).data["error"]["code"], "invalid_slot")
        self.assertEqual(self.book(c, 15).data["error"]["code"], "invalid_slot")  # after hours
        self.assertEqual(self.book(c, 10, day=next_weekday(6)).data["error"]["code"], "invalid_slot")  # Sunday

    def test_time_off_blocks_booking(self):
        DoctorTimeOff.objects.create(doctor=self.doctor, start_datetime=slot_dt(self.day, 9),
                                     end_datetime=slot_dt(self.day, 12))
        r = self.book(self.login(self.p1), 10)
        self.assertEqual(r.status_code, 409)

    def test_doctor_not_accepting(self):
        self.doctor.is_accepting_appointments = False
        self.doctor.save()
        r = self.book(self.login(self.p1))
        self.assertEqual(r.data["error"]["code"], "doctor_not_accepting")

    def test_unknown_doctor(self):
        r = self.login(self.p1).post("/api/appointments/", {"doctor_id": 9999,
                                     "start_datetime": slot_dt(self.day, 10).isoformat()}, format="json")
        self.assertEqual(r.status_code, 404)
        self.assertEqual(r.data["error"]["code"], "doctor_not_found")

    def test_unlisted_doctor_cannot_be_booked(self):
        self.doctor.is_listed = False
        self.doctor.save()
        self.assertEqual(self.book(self.login(self.p1)).status_code, 404)

    def test_missing_fields_validation(self):
        r = self.login(self.p1).post("/api/appointments/", {}, format="json")
        self.assertEqual(r.status_code, 400)
        self.assertEqual(r.data["error"]["code"], "validation_error")


class CancelRescheduleTests(BaseAPITest):
    def setUp(self):
        super().setUp()
        self.c1 = self.login(self.p1)
        self.appt = self.book(self.c1, 10).data

    def test_cancel_frees_slot(self):
        r = self.c1.post(f"/api/appointments/{self.appt['id']}/cancel/", {"reason": "Busy"}, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["status"], "CANCELLED")
        self.assertEqual(self.book(self.login(self.p2), 10).status_code, 201)  # slot is free again

    def test_cancel_twice_rejected(self):
        self.c1.post(f"/api/appointments/{self.appt['id']}/cancel/")
        r = self.c1.post(f"/api/appointments/{self.appt['id']}/cancel/")
        self.assertEqual(r.status_code, 409)
        self.assertEqual(r.data["error"]["code"], "not_cancellable")

    def test_cancellation_window(self):
        Appointment.objects.filter(pk=self.appt["id"]).update(
            start_datetime=timezone.now() + timedelta(minutes=30), active_start=timezone.now() + timedelta(minutes=30))
        r = self.c1.post(f"/api/appointments/{self.appt['id']}/cancel/")
        self.assertEqual(r.status_code, 409)
        self.assertEqual(r.data["error"]["code"], "change_window_closed")

    def test_reschedule_success_atomic(self):
        r = self.c1.post(f"/api/appointments/{self.appt['id']}/reschedule/",
                         {"start_datetime": slot_dt(self.day, 11).isoformat()}, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.book(self.login(self.p2), 10).status_code, 201)  # old slot released
        self.assertEqual(self.book(self.login(self.p2), 11, doctor=self.doctor2).status_code, 201)

    def test_reschedule_to_taken_slot_keeps_original(self):
        self.book(self.login(self.p2), 11)
        r = self.c1.post(f"/api/appointments/{self.appt['id']}/reschedule/",
                         {"start_datetime": slot_dt(self.day, 11).isoformat()}, format="json")
        self.assertEqual(r.status_code, 409)
        a = Appointment.objects.get(pk=self.appt["id"])
        self.assertEqual(timezone.localtime(a.start_datetime).hour, 10)
        self.assertEqual(a.status, Status.CONFIRMED)

    def test_reschedule_to_own_slot_neighbour_allowed_excludes_self(self):
        # moving to the same slot is "valid" because the appointment ignores itself
        r = self.c1.post(f"/api/appointments/{self.appt['id']}/reschedule/",
                         {"start_datetime": slot_dt(self.day, 10).isoformat()}, format="json")
        self.assertEqual(r.status_code, 200)

    def test_cannot_reschedule_cancelled(self):
        self.c1.post(f"/api/appointments/{self.appt['id']}/cancel/")
        r = self.c1.post(f"/api/appointments/{self.appt['id']}/reschedule/",
                         {"start_datetime": slot_dt(self.day, 11).isoformat()}, format="json")
        self.assertEqual(r.data["error"]["code"], "not_reschedulable")


class IsolationTests(BaseAPITest):
    def setUp(self):
        super().setUp()
        self.a1 = self.book(self.login(self.p1), 10).data["id"]
        self.a2 = self.book(self.login(self.p2), 11, doctor=self.doctor2).data["id"]

    def test_patient_sees_only_own(self):
        r = self.login(self.p1).get("/api/appointments/")
        self.assertEqual([a["id"] for a in r.data["results"]], [self.a1])
        self.assertNotIn("patient_email", r.data["results"][0])

    def test_patient_cannot_touch_others(self):
        c = self.login(self.p1)
        self.assertEqual(c.get(f"/api/appointments/{self.a2}/").status_code, 404)
        self.assertEqual(c.post(f"/api/appointments/{self.a2}/cancel/").status_code, 404)
        self.assertEqual(c.post(f"/api/appointments/{self.a2}/reschedule/",
                                {"start_datetime": slot_dt(self.day, 9).isoformat()}, format="json").status_code, 404)
        self.assertEqual(c.patch(f"/api/appointments/{self.a2}/", {"reason_for_visit": "x"},
                                 format="json").status_code, 404)

    def test_doctor_sees_only_assigned_with_minimal_patient_data(self):
        r = self.login(self.doc_user).get("/api/appointments/")
        self.assertEqual([a["id"] for a in r.data["results"]], [self.a1])
        row = r.data["results"][0]
        self.assertEqual(row["patient_name"], "Patient One")
        self.assertNotIn("patient_email", row)
        self.assertNotIn("patient_phone", row)
        self.assertEqual(self.login(self.doc_user).get(f"/api/appointments/{self.a2}/").status_code, 404)

    def test_admin_sees_all_with_contact_details(self):
        r = self.login(self.admin).get("/api/appointments/")
        self.assertEqual(r.data["count"], 2)
        self.assertEqual(r.data["results"][0]["patient_email"] in ("p1@t.test", "p2@t.test"), True)

    def test_admin_search_and_filters(self):
        c = self.login(self.admin)
        self.assertEqual(c.get("/api/appointments/?search=Patient Two").data["count"], 1)
        self.assertEqual(c.get(f"/api/appointments/?search={self.a1}").data["count"], 1)
        self.assertEqual(c.get(f"/api/appointments/?doctor={self.doctor.id}").data["count"], 1)
        self.assertEqual(c.get(f"/api/appointments/?date={self.day.isoformat()}").data["count"], 2)
        self.assertEqual(c.get("/api/appointments/?status=CANCELLED").data["count"], 0)
        self.assertEqual(c.get("/api/appointments/?date=nope").status_code, 400)

    def test_unauthenticated_blocked(self):
        self.assertEqual(self.client.get("/api/appointments/").status_code, 403)

    def test_patient_cannot_set_status(self):
        r = self.login(self.p1).patch(f"/api/appointments/{self.a1}/", {"status": "COMPLETED"}, format="json")
        self.assertEqual(r.status_code, 403)


class DoctorActionTests(BaseAPITest):
    def setUp(self):
        super().setUp()
        self.aid = self.book(self.login(self.p1), 10).data["id"]

    def test_cannot_complete_future_appointment(self):
        r = self.login(self.doc_user).patch(f"/api/appointments/{self.aid}/", {"status": "COMPLETED"}, format="json")
        self.assertEqual(r.data["error"]["code"], "too_early")

    def test_complete_and_no_show_after_start(self):
        Appointment.objects.filter(pk=self.aid).update(start_datetime=timezone.now() - timedelta(hours=1))
        r = self.login(self.doc_user).patch(f"/api/appointments/{self.aid}/", {"status": "COMPLETED"}, format="json")
        self.assertEqual(r.data["status"], "COMPLETED")
        again = self.login(self.doc_user).patch(f"/api/appointments/{self.aid}/", {"status": "NO_SHOW"}, format="json")
        self.assertEqual(again.status_code, 409)

    def test_other_doctor_cannot_update(self):
        r = self.login(self.doc2_user).patch(f"/api/appointments/{self.aid}/", {"status": "CANCELLED"}, format="json")
        self.assertEqual(r.status_code, 404)

    def test_doctor_cannot_reschedule(self):
        r = self.login(self.doc_user).post(f"/api/appointments/{self.aid}/reschedule/",
                                           {"start_datetime": slot_dt(self.day, 11).isoformat()}, format="json")
        self.assertEqual(r.status_code, 403)

    def test_doctor_can_cancel_inside_window(self):
        Appointment.objects.filter(pk=self.aid).update(start_datetime=timezone.now() + timedelta(minutes=30))
        r = self.login(self.doc_user).post(f"/api/appointments/{self.aid}/cancel/", {"reason": "Emergency"},
                                           format="json")
        self.assertEqual(r.status_code, 200)

    def test_pending_flow_when_manual_confirmation(self):
        with self.settings(APPOINTMENT_AUTO_CONFIRM=False):
            r = self.book(self.login(self.p2), 11)
            self.assertEqual(r.data["status"], "PENDING")
            ok = self.login(self.doc_user).patch(f"/api/appointments/{r.data['id']}/", {"status": "CONFIRMED"},
                                                 format="json")
            self.assertEqual(ok.data["status"], "CONFIRMED")
            r2 = self.book(self.login(make_user("p3@t.test", Role.PATIENT)), 11, 30)
            rej = self.login(self.doc_user).patch(f"/api/appointments/{r2.data['id']}/", {"status": "REJECTED"},
                                                  format="json")
            self.assertEqual(rej.data["status"], "REJECTED")
            self.assertEqual(self.book(self.login(self.p2), 11, 30).status_code, 201)  # rejected slot is free


class DatabaseGuardTests(BaseAPITest):
    def test_unique_constraint_blocks_duplicate_active_rows(self):
        from django.db import IntegrityError, transaction
        start = slot_dt(self.day, 9)
        Appointment.objects.create(patient=self.p1, doctor=self.doctor, start_datetime=start,
                                   end_datetime=start + timedelta(minutes=30), status=Status.CONFIRMED)
        with self.assertRaises(IntegrityError), transaction.atomic():
            Appointment.objects.create(patient=self.p2, doctor=self.doctor, start_datetime=start,
                                       end_datetime=start + timedelta(minutes=30), status=Status.PENDING)
        # but a cancelled row does not block
        Appointment.objects.create(patient=self.p2, doctor=self.doctor, start_datetime=start,
                                   end_datetime=start + timedelta(minutes=30), status=Status.CANCELLED)


class ConcurrentBookingTests(TransactionTestCase):
    """Two threads try to take the same slot. Exactly one must win (needs a DB that supports threads)."""

    def test_only_one_of_parallel_bookings_wins(self):
        if connection.vendor == "sqlite":
            self.skipTest("SQLite in-memory databases cannot be shared between threads; run this on MySQL.")
        from datetime import time
        from appointments import services
        from config.exceptions import BusinessError
        from departments.models import Department
        from doctors.models import DoctorProfile, DoctorSchedule
        dept = Department.objects.create(name="X")
        d = DoctorProfile.objects.create(user=make_user("cd@t.test", Role.DOCTOR), department=dept)
        DoctorSchedule.objects.create(doctor=d, day_of_week=0, start_time=time(9), end_time=time(12))
        patients = [make_user(f"cp{i}@t.test", Role.PATIENT) for i in range(5)]
        start, results = slot_dt(next_weekday(0), 10), []

        def attempt(p):
            try:
                services.book(p, d.id, start)
                results.append("ok")
            except BusinessError:
                results.append("conflict")
            finally:
                connection.close()

        threads = [threading.Thread(target=attempt, args=(p,)) for p in patients]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(results.count("ok"), 1)
        self.assertEqual(Appointment.objects.filter(doctor=d, status=Status.CONFIRMED).count(), 1)
