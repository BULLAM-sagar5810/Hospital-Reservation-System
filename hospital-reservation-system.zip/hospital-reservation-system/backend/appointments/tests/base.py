from datetime import date, datetime, time, timedelta

from django.core.cache import cache
from django.utils import timezone
from rest_framework.test import APIClient, APITestCase

from accounts.models import PatientProfile, Role, User
from departments.models import Department
from doctors.models import DoctorProfile, DoctorSchedule

PASSWORD = "Str0ng!Pass#2026"


def make_user(email, role, name="Test User", **kw):
    u = User.objects.create_user(email=email, password=PASSWORD, name=name, role=role, **kw)
    if role == Role.PATIENT:
        PatientProfile.objects.create(user=u)
    if role == Role.ADMIN:
        u.is_staff = True
        u.save()
    return u


def next_weekday(weekday=0, min_days=3):
    """A future date (at least min_days ahead) falling on `weekday` (0 = Monday)."""
    d = timezone.localdate() + timedelta(days=min_days)
    while d.weekday() != weekday:
        d += timedelta(days=1)
    return d


def slot_dt(day, hour, minute=0):
    return timezone.make_aware(datetime.combine(day, time(hour, minute)), timezone.get_current_timezone())


class BaseAPITest(APITestCase):
    def setUp(self):
        cache.clear()  # reset throttling counters
        self.dept = Department.objects.create(name="Cardiology")
        self.doc_user = make_user("doc@t.test", Role.DOCTOR, "Doc One")
        self.doctor = DoctorProfile.objects.create(user=self.doc_user, department=self.dept,
                                                   specialization="Heart", consultation_fee=500)
        self.doc2_user = make_user("doc2@t.test", Role.DOCTOR, "Doc Two")
        self.doctor2 = DoctorProfile.objects.create(user=self.doc2_user, department=self.dept)
        for d in (self.doctor, self.doctor2):
            for wd in range(5):
                DoctorSchedule.objects.create(doctor=d, day_of_week=wd, start_time=time(9), end_time=time(12),
                                              slot_duration_minutes=30)
        self.p1 = make_user("p1@t.test", Role.PATIENT, "Patient One", phone="9111111111")
        self.p2 = make_user("p2@t.test", Role.PATIENT, "Patient Two")
        self.admin = make_user("admin@t.test", Role.ADMIN, "Admin")
        self.day = next_weekday(0)  # a Monday in the future

    def login(self, user):
        c = APIClient()
        c.force_login(user)
        return c

    def book(self, client, hour=10, minute=0, doctor=None, day=None):
        return client.post("/api/appointments/", {
            "doctor_id": (doctor or self.doctor).id,
            "start_datetime": slot_dt(day or self.day, hour, minute).isoformat(),
            "reason_for_visit": "Check-up"}, format="json")
