from django.test import override_settings
from rest_framework.test import APIClient

from accounts.models import Role, User

from .base import PASSWORD, BaseAPITest


class AuthTests(BaseAPITest):
    @override_settings(PASSWORD_HASHERS=["django.contrib.auth.hashers.PBKDF2PasswordHasher"])
    def test_register_creates_patient_and_hashes_password(self):
        r = APIClient().post("/api/auth/register/", {
            "name": "New Person", "email": "New@T.test", "phone": "9876543210",
            "password": PASSWORD, "confirm_password": PASSWORD}, format="json")
        self.assertEqual(r.status_code, 201)
        self.assertNotIn("password", r.data)
        u = User.objects.get(email="new@t.test")
        self.assertEqual(u.role, Role.PATIENT)
        self.assertNotEqual(u.password, PASSWORD)
        self.assertTrue(u.password.startswith("pbkdf2_"))

    def test_register_validation(self):
        dup = APIClient().post("/api/auth/register/", {
            "name": "X", "email": "p1@t.test", "password": PASSWORD, "confirm_password": PASSWORD}, format="json")
        self.assertEqual(dup.status_code, 400)
        self.assertEqual(dup.data["error"]["code"], "validation_error")
        self.assertIn("email", dup.data["error"]["details"])
        mismatch = APIClient().post("/api/auth/register/", {
            "name": "X", "email": "x@t.test", "password": PASSWORD, "confirm_password": "different"}, format="json")
        self.assertIn("confirm_password", mismatch.data["error"]["details"])
        weak = APIClient().post("/api/auth/register/", {
            "name": "X", "email": "x@t.test", "password": "12345678", "confirm_password": "12345678"}, format="json")
        self.assertEqual(weak.status_code, 400)

    def test_register_cannot_choose_role(self):
        APIClient().post("/api/auth/register/", {"name": "Sneaky", "email": "s@t.test", "role": "ADMIN",
                                                 "password": PASSWORD, "confirm_password": PASSWORD}, format="json")
        self.assertEqual(User.objects.get(email="s@t.test").role, Role.PATIENT)

    def test_login_me_logout(self):
        c = APIClient()
        self.assertEqual(c.get("/api/auth/me/").status_code, 403)
        bad = c.post("/api/auth/login/", {"email": "p1@t.test", "password": "wrong"}, format="json")
        self.assertEqual(bad.status_code, 401)
        ok = c.post("/api/auth/login/", {"email": "P1@t.test", "password": PASSWORD}, format="json")
        self.assertEqual(ok.status_code, 200)
        self.assertEqual(c.get("/api/auth/me/").data["email"], "p1@t.test")
        self.assertEqual(c.post("/api/auth/logout/").status_code, 204)
        self.assertEqual(c.get("/api/auth/me/").status_code, 403)

    def test_login_is_throttled(self):
        c = APIClient()
        codes = [c.post("/api/auth/login/", {"email": "x@t.test", "password": "bad"}, format="json").status_code
                 for _ in range(25)]
        self.assertIn(429, codes)

    def test_inactive_user_cannot_login(self):
        self.p1.is_active = False
        self.p1.save()
        r = APIClient().post("/api/auth/login/", {"email": "p1@t.test", "password": PASSWORD}, format="json")
        self.assertEqual(r.status_code, 401)

    def test_csrf_enforced_for_session_auth(self):
        c = APIClient(enforce_csrf_checks=True)
        c.force_login(self.p1)
        r = c.post("/api/auth/logout/")
        self.assertEqual(r.status_code, 403)

    def test_change_password(self):
        c = self.login(self.p1)
        r = c.post("/api/auth/change-password/", {"current_password": PASSWORD, "new_password": "An0ther!Pass#77"},
                   format="json")
        self.assertEqual(r.status_code, 200)
        self.p1.refresh_from_db()
        self.assertTrue(self.p1.check_password("An0ther!Pass#77"))
        bad = c.post("/api/auth/change-password/", {"current_password": "nope", "new_password": "An0ther!Pass#88"},
                     format="json")
        self.assertEqual(bad.status_code, 400)


class PermissionTests(BaseAPITest):
    def test_patient_profile_only_for_patients(self):
        self.assertEqual(self.login(self.p1).get("/api/patients/me/").status_code, 200)
        self.assertEqual(self.login(self.doc_user).get("/api/patients/me/").status_code, 403)
        self.assertEqual(APIClient().get("/api/patients/me/").status_code, 403)

    def test_patient_profile_update(self):
        r = self.login(self.p1).patch("/api/patients/me/", {"address": "1 Test Street", "name": "Renamed"},
                                      format="json")
        self.assertEqual(r.status_code, 200)
        self.p1.refresh_from_db()
        self.assertEqual(self.p1.name, "Renamed")
        self.assertEqual(self.p1.patient_profile.address, "1 Test Street")

    def test_admin_only_patient_list(self):
        self.assertEqual(self.login(self.p1).get("/api/patients/").status_code, 403)
        r = self.login(self.admin).get("/api/patients/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["count"], 2)
        r = self.login(self.admin).patch(f"/api/patients/{self.p1.id}/", {"is_active": False}, format="json")
        self.assertFalse(r.data["is_active"])

    def test_department_admin_only_writes(self):
        body = {"name": "Neurology", "description": "Brain"}
        self.assertEqual(APIClient().get("/api/departments/").status_code, 200)
        self.assertEqual(self.login(self.p1).post("/api/departments/", body, format="json").status_code, 403)
        self.assertEqual(self.login(self.doc_user).post("/api/departments/", body, format="json").status_code, 403)
        r = self.login(self.admin).post("/api/departments/", body, format="json")
        self.assertEqual(r.status_code, 201)
        r = self.login(self.admin).patch(f"/api/departments/{r.data['id']}/", {"is_active": False}, format="json")
        self.assertFalse(r.data["is_active"])
        self.assertNotIn("Neurology", [d["name"] for d in APIClient().get("/api/departments/").data])

    def test_cannot_delete_department_with_doctors(self):
        r = self.login(self.admin).delete(f"/api/departments/{self.dept.id}/")
        self.assertEqual(r.status_code, 409)

    def test_dashboards_are_role_scoped(self):
        self.assertEqual(self.login(self.p1).get("/api/dashboard/admin/").status_code, 403)
        self.assertEqual(self.login(self.p1).get("/api/dashboard/doctor/").status_code, 403)
        self.assertEqual(self.login(self.doc_user).get("/api/dashboard/patient/").status_code, 403)
        self.assertEqual(self.login(self.p1).get("/api/dashboard/patient/").status_code, 200)
        self.assertEqual(self.login(self.doc_user).get("/api/dashboard/doctor/").status_code, 200)
        r = self.login(self.admin).get("/api/dashboard/admin/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["total_patients"], 2)
