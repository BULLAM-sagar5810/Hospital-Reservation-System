"""Creates 100% fictional development data. Safe to run many times (it never duplicates rows).

    python manage.py seed_data            # create / top-up
    python manage.py seed_data --reset    # remove ONLY the seeded demo accounts, then re-create
"""
import os
from datetime import time, timedelta

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from accounts.models import PatientProfile, Role, User
from appointments.models import ACTIVE_STATUSES, Appointment, Status
from appointments.services import day_slots
from departments.models import Department
from doctors.models import DoctorProfile, DoctorSchedule, DoctorTimeOff

DEPARTMENTS = [
    ("Cardiology", "Heart and blood-vessel care."),
    ("Dermatology", "Skin, hair and nail care."),
    ("Orthopedics", "Bones, joints and muscles."),
    ("Neurology", "Brain and nervous system care."),
    ("Pediatrics", "Healthcare for children."),
    ("General Medicine", "First point of contact for common health concerns."),
]
# (name, department, specialization, qualifications, years, fee)
DOCTORS = [
    ("Anita Rao", "Cardiology", "Interventional Cardiology", "MBBS, MD, DM (Cardiology)", 15, 900),
    ("Vikram Iyer", "Cardiology", "Heart Failure", "MBBS, MD, DM", 11, 800),
    ("Sneha Kulkarni", "Dermatology", "Cosmetic Dermatology", "MBBS, MD (Dermatology)", 9, 600),
    ("Rahul Menon", "Orthopedics", "Joint Replacement", "MBBS, MS (Ortho)", 14, 850),
    ("Priya Nair", "Orthopedics", "Sports Medicine", "MBBS, DNB (Ortho)", 7, 700),
    ("Arjun Reddy", "Neurology", "Epilepsy Care", "MBBS, MD, DM (Neurology)", 12, 950),
    ("Meera Pillai", "Pediatrics", "Child Development", "MBBS, MD (Pediatrics)", 10, 500),
    ("Karthik Sharma", "Pediatrics", "Neonatology", "MBBS, DCH", 6, 450),
    ("Lakshmi Devi", "General Medicine", "Family Medicine", "MBBS, MD (Medicine)", 18, 400),
    ("Suresh Babu", "General Medicine", "Internal Medicine", "MBBS, MD", 8, 350),
]
FIRST = ["Aarav", "Diya", "Ishaan", "Kavya", "Rohan", "Ananya", "Vihaan", "Saanvi", "Aditya", "Myra",
         "Krish", "Navya", "Sai", "Tara", "Dev", "Riya", "Neel", "Pooja", "Om", "Zara"]
LAST = ["Verma", "Gupta", "Patel", "Singh", "Das"]
REASONS = ["Routine check-up", "Follow-up visit", "Consultation", "Report review", "New appointment"]

# (status, days from today, slot index)  -- negative days = past
APPT_PLAN = ([(Status.COMPLETED, -d, i) for i, d in enumerate([3, 5, 8, 10, 14, 20])]
             + [(Status.NO_SHOW, -4, 1), (Status.NO_SHOW, -11, 2), (Status.REJECTED, -2, 3)]
             + [(Status.CANCELLED, d, 2 + i) for i, d in enumerate([2, 6, -6])]
             + [(Status.CONFIRMED, d, i % 6) for i, d in enumerate([1, 1, 2, 3, 4, 5, 7, 9])]
             + [(Status.PENDING, d, 4 + i) for i, d in enumerate([2, 3, 6, 8])])


class Command(BaseCommand):
    help = "Populate the database with fictional demo data."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Delete the seeded demo accounts first")

    @transaction.atomic
    def handle(self, *args, **opts):
        password = os.environ.get("SEED_PASSWORD", "Demo@12345")
        if opts["reset"]:
            Appointment.objects.filter(doctor__user__email__endswith="@hospital.test").delete()
            Appointment.objects.filter(patient__email__endswith="@example.test").delete()
            User.objects.filter(email__endswith="@hospital.test").delete()
            User.objects.filter(email__endswith="@example.test").delete()
            self.stdout.write("Removed previous demo accounts.")

        admin, created = User.objects.get_or_create(
            email="admin@hospital.test",
            defaults=dict(name="Demo Admin", role=Role.ADMIN, is_staff=True, is_superuser=True))
        if created:
            admin.set_password(password)
            admin.save()

        depts = {n: Department.objects.get_or_create(name=n, defaults={"description": d})[0] for n, d in DEPARTMENTS}

        doctors = []
        for name, dept, spec, qual, years, fee in DOCTORS:
            email = "dr." + name.lower().replace(" ", ".") + "@hospital.test"
            user, created = User.objects.get_or_create(email=email, defaults=dict(name=name, role=Role.DOCTOR,
                                                                                    phone="9000000000"))
            if created:
                user.set_password(password)
                user.save()
            doc, _ = DoctorProfile.objects.get_or_create(user=user, defaults=dict(
                department=depts[dept], specialization=spec, qualifications=qual, experience_years=years,
                consultation_fee=fee, biography=f"Dr. {name} sees patients in the {dept} department. "
                                                 "(Fictional demo profile.)"))
            if not doc.schedules.exists():
                for day in range(5):  # Monday-Friday
                    DoctorSchedule.objects.create(doctor=doc, day_of_week=day, start_time=time(9), end_time=time(13))
                    DoctorSchedule.objects.create(doctor=doc, day_of_week=day, start_time=time(14), end_time=time(17))
                if len(doctors) % 2 == 0:
                    DoctorSchedule.objects.create(doctor=doc, day_of_week=5, start_time=time(9), end_time=time(12))
            doctors.append(doc)

        # leave records
        now = timezone.now()
        for idx, (days, length, why) in {1: (10, 3, "Conference"), 4: (4, 2, "Personal leave"),
                                         7: (-9, 2, "Training (past)")}.items():
            start = (now + timedelta(days=days)).replace(hour=0, minute=0, second=0, microsecond=0)
            DoctorTimeOff.objects.get_or_create(doctor=doctors[idx], start_datetime=start,
                                                defaults=dict(end_datetime=start + timedelta(days=length), reason=why))

        patients = []
        for i in range(20):
            email = f"patient{i + 1:02d}@example.test"
            user, created = User.objects.get_or_create(email=email, defaults=dict(
                name=f"{FIRST[i]} {LAST[i % 5]}", role=Role.PATIENT, phone=f"90000{i + 1:05d}"))
            if created:
                user.set_password(password)
                user.save()
            PatientProfile.objects.get_or_create(user=user)
            patients.append(user)

        made = 0
        if not Appointment.objects.filter(patient__in=patients).exists():
            today = timezone.localdate()
            for n, (status, offset, slot_idx) in enumerate(APPT_PLAN):
                doctor = doctors[n % len(doctors)]
                patient = patients[(n * 3) % len(patients)]
                day, step = today + timedelta(days=offset), (1 if offset >= 0 else -1)
                while not day_slots(doctor, day):  # skip days off
                    day += timedelta(days=step)
                slots = day_slots(doctor, day)
                for k in range(len(slots)):
                    start, end = slots[(slot_idx + k) % len(slots)]
                    busy = Appointment.objects.filter(doctor=doctor, start_datetime=start,
                                                      status__in=ACTIVE_STATUSES).exists()
                    patient_busy = Appointment.objects.filter(patient=patient, start_datetime=start,
                                                              status__in=ACTIVE_STATUSES).exists()
                    if not (busy and status in ACTIVE_STATUSES) and not patient_busy:
                        Appointment(patient=patient, doctor=doctor, start_datetime=start, end_datetime=end,
                                    status=status, reason_for_visit=REASONS[n % len(REASONS)],
                                    cancellation_reason="Patient request" if status == Status.CANCELLED else "").save()
                        made += 1
                        break
        self.stdout.write(self.style.SUCCESS(
            f"Seed complete: {len(depts)} departments, {len(doctors)} doctors, {len(patients)} patients, "
            f"{made} new appointments."))
        self.stdout.write(f"Demo password for every demo account: {password}  (development only!)")
        self.stdout.write("Admin: admin@hospital.test | Doctor: dr.anita.rao@hospital.test | "
                          "Patient: patient01@example.test")
