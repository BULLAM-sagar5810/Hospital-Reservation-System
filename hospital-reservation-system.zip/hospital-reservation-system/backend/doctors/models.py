from django.conf import settings
from django.db import models

from departments.models import Department


class DoctorProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="doctor_profile")
    department = models.ForeignKey(Department, on_delete=models.PROTECT, related_name="doctors")
    specialization = models.CharField(max_length=120, blank=True)
    qualifications = models.CharField(max_length=255, blank=True)
    experience_years = models.PositiveSmallIntegerField(default=0)
    consultation_fee = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    biography = models.TextField(blank=True)
    is_accepting_appointments = models.BooleanField(default=True)  # doctor can pause bookings
    is_listed = models.BooleanField(default=True)  # admin can hide the doctor from the public directory

    class Meta:
        ordering = ["user__name"]
        indexes = [models.Index(fields=["is_listed", "department"])]

    def __str__(self):
        return f"Dr. {self.user.name}"


class DoctorSchedule(models.Model):
    """Recurring weekly working hours. day_of_week follows Python: 0 = Monday ... 6 = Sunday."""

    doctor = models.ForeignKey(DoctorProfile, on_delete=models.CASCADE, related_name="schedules")
    day_of_week = models.PositiveSmallIntegerField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    slot_duration_minutes = models.PositiveSmallIntegerField(default=30)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["day_of_week", "start_time"]
        indexes = [models.Index(fields=["doctor", "day_of_week"])]


class DoctorTimeOff(models.Model):
    doctor = models.ForeignKey(DoctorProfile, on_delete=models.CASCADE, related_name="time_off")
    start_datetime = models.DateTimeField()
    end_datetime = models.DateTimeField()
    reason = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["start_datetime"]
        indexes = [models.Index(fields=["doctor", "start_datetime"])]
