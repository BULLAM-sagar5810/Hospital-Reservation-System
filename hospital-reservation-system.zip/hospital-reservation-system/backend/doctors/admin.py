from django.contrib import admin

from .models import DoctorProfile, DoctorSchedule, DoctorTimeOff

admin.site.register(DoctorProfile)
admin.site.register(DoctorSchedule)
admin.site.register(DoctorTimeOff)
