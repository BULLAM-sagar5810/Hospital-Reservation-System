from datetime import date as date_cls

from django.db.models import Q
from rest_framework import filters, mixins, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import SAFE_METHODS, AllowAny, BasePermission, IsAuthenticated
from rest_framework.response import Response

from accounts.models import Role
from accounts.permissions import IsAdminRole
from config.exceptions import BusinessError

from .models import DoctorProfile, DoctorSchedule, DoctorTimeOff
from .serializers import (DOCTOR_SELF_FIELDS, DoctorCreateSerializer, DoctorScheduleSerializer,
                          DoctorSerializer, DoctorTimeOffSerializer)


def is_admin(u):
    return u.is_authenticated and u.role == Role.ADMIN


class CanEditDoctor(BasePermission):
    """Admin may edit any doctor; a doctor may edit only their own profile."""

    def has_object_permission(self, request, view, obj):
        u = request.user
        return is_admin(u) or (u.role == Role.DOCTOR and obj.user_id == u.id)


class DoctorViewSet(mixins.ListModelMixin, mixins.RetrieveModelMixin, mixins.CreateModelMixin,
                    mixins.UpdateModelMixin, viewsets.GenericViewSet):
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["user__name", "specialization", "department__name"]
    ordering_fields = ["user__name", "consultation_fee", "experience_years"]
    http_method_names = ["get", "post", "patch", "head", "options"]

    def get_serializer_class(self):
        return DoctorCreateSerializer if self.action == "create" else DoctorSerializer

    def get_permissions(self):
        if self.action in ("list", "retrieve", "availability"):
            return [AllowAny()]
        if self.action == "create":
            return [IsAdminRole()]
        return [IsAuthenticated(), CanEditDoctor()]

    def get_queryset(self):
        qs = DoctorProfile.objects.select_related("user", "department")
        u = self.request.user
        if is_admin(u):
            listed = self.request.query_params.get("is_listed")
            if listed in ("true", "false"):
                qs = qs.filter(is_listed=(listed == "true"))
        elif u.is_authenticated and u.role == Role.DOCTOR:
            qs = qs.filter(Q(is_listed=True, user__is_active=True) | Q(user=u))
        else:
            qs = qs.filter(is_listed=True, user__is_active=True, department__is_active=True)
        dept = self.request.query_params.get("department")
        if dept and dept.isdigit():
            qs = qs.filter(department_id=int(dept))
        return qs

    def partial_update(self, request, *args, **kwargs):
        if not is_admin(request.user):
            forbidden = set(request.data.keys()) - DOCTOR_SELF_FIELDS
            if forbidden:
                raise BusinessError("forbidden_field",
                                    "You may not change: " + ", ".join(sorted(forbidden)), 403)
        return super().partial_update(request, *args, **kwargs)

    @action(detail=True, methods=["get"])
    def availability(self, request, pk=None):
        from appointments.services import available_slots  # local import avoids a circular import
        doctor = self.get_object()
        raw = request.query_params.get("date")
        try:
            day = date_cls.fromisoformat(raw)
        except (TypeError, ValueError):
            raise BusinessError("invalid_date", "Provide a date in YYYY-MM-DD format.")
        slots = available_slots(doctor, day)
        return Response({"doctor_id": doctor.id, "date": day.isoformat(),
                         "accepting_appointments": doctor.is_accepting_appointments,
                         "slots": [{"start": s.isoformat(), "end": e.isoformat()} for s, e in slots]})


class _DoctorOwnedViewSet(viewsets.ModelViewSet):
    """Shared logic: admins manage everything, doctors only their own rows."""
    pagination_class = None
    http_method_names = ["get", "post", "patch", "delete", "head", "options"]

    def get_permissions(self):
        return [IsAuthenticated(), _DoctorOrAdmin()]

    def get_queryset(self):
        qs = self.model.objects.all()
        u = self.request.user
        if u.role == Role.DOCTOR:
            qs = qs.filter(doctor__user=u)
        doctor = self.request.query_params.get("doctor")
        if doctor and doctor.isdigit() and is_admin(u):
            qs = qs.filter(doctor_id=int(doctor))
        return qs

    def _resolve_doctor(self, serializer):
        u = self.request.user
        if u.role == Role.DOCTOR:
            return u.doctor_profile
        doctor = serializer.validated_data.get("doctor")
        if not doctor:
            raise BusinessError("doctor_required", "Admins must provide a doctor id.")
        return doctor

    def get_serializer_context(self):
        ctx = super().get_serializer_context()
        u = self.request.user
        if u.is_authenticated and u.role == Role.DOCTOR and hasattr(u, "doctor_profile"):
            ctx["doctor"] = u.doctor_profile
        return ctx

    def perform_create(self, serializer):
        serializer.save(doctor=self._resolve_doctor(serializer))

    def perform_update(self, serializer):
        if self.request.user.role == Role.DOCTOR:
            serializer.validated_data.pop("doctor", None)  # a doctor cannot move a row to another doctor
        serializer.save()


class _DoctorOrAdmin(BasePermission):
    def has_permission(self, request, view):
        u = request.user
        return bool(u.is_authenticated and u.is_active and u.role in (Role.DOCTOR, Role.ADMIN))


class DoctorScheduleViewSet(_DoctorOwnedViewSet):
    model = DoctorSchedule
    serializer_class = DoctorScheduleSerializer


class DoctorTimeOffViewSet(_DoctorOwnedViewSet):
    model = DoctorTimeOff
    serializer_class = DoctorTimeOffSerializer
