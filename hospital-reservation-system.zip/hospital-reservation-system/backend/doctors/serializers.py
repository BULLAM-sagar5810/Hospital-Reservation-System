from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.db import transaction
from rest_framework import serializers

from accounts.models import Role
from departments.models import Department

from .models import DoctorProfile, DoctorSchedule, DoctorTimeOff

User = get_user_model()


class DoctorSerializer(serializers.ModelSerializer):
    """Public representation. No e-mail or phone is exposed."""
    name = serializers.CharField(source="user.name", read_only=True)
    department_name = serializers.CharField(source="department.name", read_only=True)
    department_id = serializers.PrimaryKeyRelatedField(source="department", queryset=Department.objects.all())

    class Meta:
        model = DoctorProfile
        fields = ["id", "name", "department_id", "department_name", "specialization", "qualifications",
                  "experience_years", "consultation_fee", "biography", "is_accepting_appointments", "is_listed"]
        read_only_fields = ["id"]


class DoctorCreateSerializer(DoctorSerializer):
    """Admin only: creates the login account and the profile together."""
    new_name = serializers.CharField(write_only=True, max_length=120)
    email = serializers.EmailField(write_only=True)
    phone = serializers.CharField(write_only=True, required=False, allow_blank=True)
    password = serializers.CharField(write_only=True)

    class Meta(DoctorSerializer.Meta):
        fields = DoctorSerializer.Meta.fields + ["new_name", "email", "phone", "password"]

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("An account with this email already exists.")
        return value.lower()

    def validate_password(self, value):
        validate_password(value)
        return value

    @transaction.atomic
    def create(self, validated_data):
        user = User.objects.create_user(
            email=validated_data.pop("email"), password=validated_data.pop("password"),
            name=validated_data.pop("new_name"), phone=validated_data.pop("phone", ""), role=Role.DOCTOR)
        return DoctorProfile.objects.create(user=user, **validated_data)

    def to_representation(self, instance):
        return DoctorSerializer(instance, context=self.context).data


# Fields a doctor may edit on their own profile (not department, fee or listing)
DOCTOR_SELF_FIELDS = {"specialization", "qualifications", "experience_years", "biography", "is_accepting_appointments"}


class _SlotValidation:
    def _check_times(self, attrs, instance=None):
        start = attrs.get("start_time", getattr(instance, "start_time", None))
        end = attrs.get("end_time", getattr(instance, "end_time", None))
        if start and end and end <= start:
            raise serializers.ValidationError({"end_time": "End time must be after start time."})


class DoctorScheduleSerializer(_SlotValidation, serializers.ModelSerializer):
    doctor = serializers.PrimaryKeyRelatedField(queryset=DoctorProfile.objects.all(), required=False)

    class Meta:
        model = DoctorSchedule
        fields = ["id", "doctor", "day_of_week", "start_time", "end_time", "slot_duration_minutes", "is_active"]

    def validate_day_of_week(self, v):
        if not 0 <= v <= 6:
            raise serializers.ValidationError("Use 0 (Monday) to 6 (Sunday).")
        return v

    def validate_slot_duration_minutes(self, v):
        if not 5 <= v <= 240:
            raise serializers.ValidationError("Slot duration must be between 5 and 240 minutes.")
        return v

    def validate(self, attrs):
        self._check_times(attrs, self.instance)
        doctor = attrs.get("doctor") or (self.instance.doctor if self.instance else self.context.get("doctor"))
        if doctor:
            day = attrs.get("day_of_week", getattr(self.instance, "day_of_week", None))
            start = attrs.get("start_time", getattr(self.instance, "start_time", None))
            end = attrs.get("end_time", getattr(self.instance, "end_time", None))
            clash = DoctorSchedule.objects.filter(doctor=doctor, day_of_week=day, is_active=True,
                                                  start_time__lt=end, end_time__gt=start)
            if self.instance:
                clash = clash.exclude(pk=self.instance.pk)
            if clash.exists():
                raise serializers.ValidationError("This time range overlaps another schedule on the same day.")
        return attrs


class DoctorTimeOffSerializer(serializers.ModelSerializer):
    doctor = serializers.PrimaryKeyRelatedField(queryset=DoctorProfile.objects.all(), required=False)

    class Meta:
        model = DoctorTimeOff
        fields = ["id", "doctor", "start_datetime", "end_datetime", "reason"]

    def validate(self, attrs):
        s = attrs.get("start_datetime", getattr(self.instance, "start_datetime", None))
        e = attrs.get("end_datetime", getattr(self.instance, "end_datetime", None))
        if s and e and e <= s:
            raise serializers.ValidationError({"end_datetime": "End must be after start."})
        return attrs
