from rest_framework.routers import DefaultRouter

from .views import DoctorScheduleViewSet, DoctorTimeOffViewSet, DoctorViewSet

router = DefaultRouter()
router.register("doctors", DoctorViewSet, basename="doctor")
router.register("schedules", DoctorScheduleViewSet, basename="schedule")
router.register("time-off", DoctorTimeOffViewSet, basename="time-off")
urlpatterns = router.urls
