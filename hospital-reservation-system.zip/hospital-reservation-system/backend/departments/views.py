from rest_framework import filters, viewsets
from rest_framework.permissions import SAFE_METHODS

from accounts.models import Role
from accounts.permissions import IsAdminRole
from config.exceptions import BusinessError

from .models import Department
from .serializers import DepartmentSerializer


class DepartmentViewSet(viewsets.ModelViewSet):
    serializer_class = DepartmentSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ["name"]
    pagination_class = None  # only a handful of departments

    def get_permissions(self):
        from rest_framework.permissions import AllowAny
        return [AllowAny()] if self.request.method in SAFE_METHODS else [IsAdminRole()]

    def get_queryset(self):
        qs = Department.objects.all()
        u = self.request.user
        if not (u.is_authenticated and u.role == Role.ADMIN):
            qs = qs.filter(is_active=True)
        return qs

    def perform_destroy(self, instance):
        if instance.doctors.exists():
            raise BusinessError("department_in_use",
                                "This department still has doctors. Deactivate it instead of deleting.", 409)
        instance.delete()
