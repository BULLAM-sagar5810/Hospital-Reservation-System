from rest_framework import serializers

from .models import Department


class DepartmentSerializer(serializers.ModelSerializer):
    doctor_count = serializers.SerializerMethodField()

    class Meta:
        model = Department
        fields = ["id", "name", "description", "is_active", "created_at", "doctor_count"]
        read_only_fields = ["id", "created_at"]

    def get_doctor_count(self, obj):
        return obj.doctors.filter(is_listed=True, user__is_active=True).count()
