"""One consistent error shape:  {"error": {"code": "...", "message": "...", "details": {...}}}"""
from rest_framework import status
from rest_framework.exceptions import APIException
from rest_framework.views import exception_handler


class BusinessError(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_code = "bad_request"

    def __init__(self, code, message, status_code=None):
        self.code = code
        if status_code:
            self.status_code = status_code
        super().__init__(detail=message, code=code)


def custom_exception_handler(exc, context):
    response = exception_handler(exc, context)
    if response is None:
        return None
    data = response.data
    if isinstance(exc, BusinessError):
        body = {"code": exc.code, "message": str(exc.detail)}
    elif response.status_code == 400:
        body = {"code": "validation_error", "message": "Please correct the highlighted fields.", "details": data}
    else:
        message = data.get("detail", "Request failed.") if isinstance(data, dict) else "Request failed."
        code = getattr(exc, "default_code", "error")
        body = {"code": code, "message": str(message)}
    response.data = {"error": body}
    return response
