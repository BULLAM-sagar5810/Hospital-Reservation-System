# Setup on Windows (PowerShell + VS Code)

## 1. Install the tools
```powershell
python --version        # need 3.10+ ; install from python.org (tick "Add Python to PATH") if missing
node --version          # need 18+ ; install the LTS version from nodejs.org
npm --version
git --version           # git-scm.com
```
Install **MySQL Server 8** and **MySQL Workbench** with the MySQL Installer (mysql.com/downloads/installer). Remember the root password you choose.

## 2. Create the MySQL database and a restricted user
Open MySQL Workbench → connect as root → File → Open SQL Script → `database/create_database.sql`.
**Edit the password first**, then run it (lightning icon).

## 3. Backend
```powershell
cd hospital-reservation-system\backend
python -m venv venv
.\venv\Scripts\Activate.ps1        # if blocked: Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env        # then open .env and set DJANGO_SECRET_KEY and DB_PASSWORD
python -c "import secrets; print(secrets.token_urlsafe(50))"   # use this output as DJANGO_SECRET_KEY
python manage.py migrate
python manage.py createsuperuser   # this becomes an ADMIN (role is set automatically)
python manage.py seed_data         # fictional demo data (safe to repeat)
python manage.py runserver
```
Open http://127.0.0.1:8000/api/docs/ – Swagger should load. Django admin: http://127.0.0.1:8000/admin/

*No MySQL yet?* Set `DB_ENGINE=sqlite` in `.env` to try everything with a local file first.

If `pip install mysqlclient` fails on Windows: upgrade pip, make sure Python is 64-bit and 3.10–3.13 (wheels exist); otherwise install "Microsoft C++ Build Tools" or `pip install pymysql` and add
`import pymysql; pymysql.install_as_MySQLdb()` at the top of `config/__init__.py`.

## 4. Frontend (new terminal)
```powershell
cd hospital-reservation-system\frontend
npm install
npm run dev
```
Open http://localhost:5173. The Vite dev server forwards `/api` to Django (see `vite.config.js`), so no CORS setup is needed in development.

## 5. Test accounts (password `Demo@12345`)
| Role | Email |
|---|---|
| Admin | admin@hospital.test |
| Doctor | dr.anita.rao@hospital.test (all doctors: `dr.<first>.<last>@hospital.test`) |
| Patient | patient01@example.test … patient20@example.test |

## 6. Run the tests
```powershell
cd backend ; python manage.py test          # one concurrency test runs only on MySQL
cd ..\frontend ; npm test
```
For MySQL the user needs permission to create `test_hospital_db` (the SQL script grants it).

## 7. Troubleshooting
| Problem | Fix |
|---|---|
| `Access denied for user` | wrong `DB_USER`/`DB_PASSWORD`; re-run the SQL script |
| `Can't connect to MySQL server` | start the MySQL80 service (Services app) |
| `ModuleNotFoundError` | virtual environment not active – run `Activate.ps1` |
| Login works but POST gives 403 "CSRF" | open the site through http://localhost:5173 (not 127.0.0.1:8000) and check `CSRF_TRUSTED_ORIGINS` |
| React shows "Cannot reach the server" | Django not running on port 8000 |
| No slots shown | pick a weekday; doctors work Mon–Fri (some Sat) 09:00–17:00; dates in the past have none |
| `tzdata` / ZoneInfo error | `pip install tzdata` |
| Port already in use | `netstat -ano | findstr :8000` then `taskkill /PID <pid> /F` |
