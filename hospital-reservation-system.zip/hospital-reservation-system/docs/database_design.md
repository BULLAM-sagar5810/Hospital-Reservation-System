# Database design

```
accounts_user 1───1 accounts_patientprofile
accounts_user 1───1 doctors_doctorprofile ─── N─1 departments_department
doctors_doctorprofile 1───N doctors_doctorschedule      (weekly working hours)
doctors_doctorprofile 1───N doctors_doctortimeoff       (leave)
accounts_user (patient) 1───N appointments_appointment N───1 doctors_doctorprofile
accounts_user 1───N appointments_notification N───0..1 appointments_appointment
```

| Table | Purpose | Notes |
|---|---|---|
| accounts_user | one login table for all roles | `email` unique, `role` indexed, password stored as a PBKDF2 hash by Django |
| accounts_patientprofile | optional patient details | one-to-one with user; only date of birth and address |
| departments_department | Cardiology, … | `name` unique, `is_active` |
| doctors_doctorprofile | doctor details | one-to-one with user, FK to department (`PROTECT`), `is_listed` (admin) and `is_accepting_appointments` (doctor) |
| doctors_doctorschedule | recurring hours | `day_of_week` 0=Mon…6=Sun, `slot_duration_minutes`; overlapping ranges rejected by the serializer |
| doctors_doctortimeoff | leave periods | blocks slots that overlap the period |
| appointments_appointment | bookings | see below |
| appointments_notification | in-app messages | also e-mailed (console backend in dev) |

## Concepts, with examples from this project
* **Primary key** – `id` of every table uniquely identifies a row (`appointments_appointment.id = 25`).
* **One-to-one** – a user has at most one patient profile / doctor profile (`user_id` is UNIQUE).
* **One-to-many** – one doctor has many appointments (`appointment.doctor_id` → `doctorprofile.id`).
* **Foreign key** – `doctor_id` must point to a real doctor; MySQL refuses otherwise. `PROTECT` stops deleting a doctor who has bookings.
* **Index** – `(doctor_id, start_datetime)` makes "this doctor's day" fast, like a book's index.
* **Unique constraint** – see the next section.

## Double-booking protection (three layers)
1. **Validation** (`appointments/services.py::validate_slot`) – schedule, leave, past, conflicting bookings.
2. **Row lock** – `book()` runs in a transaction and does `SELECT … FOR UPDATE` on the doctor's row, so two simultaneous bookings for the same doctor are processed one after the other.
3. **Database constraint** – `UNIQUE(doctor_id, active_start)`. `active_start` equals `start_datetime` while the booking is PENDING/CONFIRMED and is `NULL` otherwise. MySQL does not support partial unique indexes, but allows many NULLs in a UNIQUE index, so cancelled/rejected/completed rows never block a slot while two active rows for the same slot are impossible – even if the application code had a bug.

## Appointment policy
* Default: bookings are **auto-confirmed** (`CONFIRMED`). Set `APPOINTMENT_AUTO_CONFIRM=False` to make them `PENDING`; the doctor then accepts (→ `CONFIRMED`) or rejects (→ `REJECTED`).
* `PENDING`/`CONFIRMED` hold the slot. `CANCELLED`, `REJECTED`, `COMPLETED`, `NO_SHOW` free it.
* Patients may cancel/reschedule up to `CANCELLATION_MIN_HOURS` (default 2) before the start. Doctors/admins may cancel at any time.
* `COMPLETED` / `NO_SHOW` can only be set after the appointment start time.

## Time zone
`TIME_ZONE = Asia/Kolkata` (`HOSPITAL_TIME_ZONE`). Django stores datetimes in UTC (`USE_TZ=True`); the API returns ISO-8601 with the +05:30 offset; React formats them in `VITE_TIME_ZONE`. Slot times are generated in hospital time, so daylight-saving changes (not relevant for India) would still be correct.
