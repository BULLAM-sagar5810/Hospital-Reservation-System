# Deployment guide (not performed – instructions only)

Typical free/cheap combination: **frontend** on Netlify or Vercel, **backend** on Render / Railway / PythonAnywhere, **MySQL** on Railway, Aiven, PlanetScale-compatible or your host's managed MySQL.

## Backend (Django)
1. Environment variables on the host (never in Git):
   `DJANGO_DEBUG=False`, `DJANGO_SECRET_KEY=<long random>`, `DJANGO_ALLOWED_HOSTS=api.example.com`, `DB_ENGINE=mysql`, `DB_*`, `CORS_ALLOWED_ORIGINS=https://app.example.com`, `CSRF_TRUSTED_ORIGINS=https://app.example.com`, `HOSPITAL_TIME_ZONE`.
   With `DJANGO_DEBUG=False` the app refuses to start without a secret key, forces HTTPS, and sets secure cookies + HSTS.
2. Build: `pip install -r requirements.txt && python manage.py collectstatic --noinput`
3. Release step: `python manage.py migrate` (run once per deploy). Create the admin: `python manage.py createsuperuser`. **Do not run `seed_data` in production.**
4. Start command: `gunicorn config.wsgi:application`. Static files are served by WhiteNoise.
5. Use a MySQL user limited to the application database (see `database/create_database.sql`, without the test-database grant).
6. Logs go to stdout (`LOG_LEVEL=INFO`); read them in the host dashboard. Enable the provider's automatic daily database backups and test a restore.
7. Set a real `EMAIL_BACKEND` (SMTP) if you want e-mails; the default only prints to the console.

## Frontend (React)
1. Build command `npm run build`, publish directory `dist`.
2. **Easiest, most secure: same-origin proxy.** Keep `VITE_API_BASE_URL=/api` and add a rewrite so the browser talks to one domain, e.g. Netlify `frontend/public/_redirects`:
   `/api/*  https://YOUR-BACKEND-HOST/api/:splat  200`
   and `/*  /index.html  200` for React Router. Cookies then stay first-party and CSRF works as in development. Add the **frontend** URL to `CSRF_TRUSTED_ORIGINS`; `DJANGO_ALLOWED_HOSTS` keeps the backend's own host name.
3. Alternative (separate domains): `VITE_API_BASE_URL=https://api.example.com/api`, `COOKIE_SAMESITE=None` on the backend (requires HTTPS), and the CORS/CSRF variables above. Browsers increasingly block third-party cookies, so prefer step 2.

## Checklist before going live
HTTPS everywhere · DEBUG off · unique secret key · allowed hosts · CORS/CSRF origins exactly your frontend URL · migrations applied · backups enabled · demo accounts absent · throttling values reviewed.

## Common problems
| Symptom | Cause |
|---|---|
| 400 Bad Request | host missing from `DJANGO_ALLOWED_HOSTS` |
| 403 CSRF failed | frontend URL missing from `CSRF_TRUSTED_ORIGINS`, or cross-site cookies blocked |
| Redirect loop | host terminates TLS but proxy header missing – `SECURE_PROXY_SSL_HEADER` is already set; set `SECURE_SSL_REDIRECT=False` only if the host itself redirects |
| Blank page on refresh | missing `/* /index.html 200` rewrite |
| Static files 404 | `collectstatic` not run |
