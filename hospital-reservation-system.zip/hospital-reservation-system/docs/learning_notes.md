# Learning notes (simple English + తెలుగు)

**Primary key / ప్రైమరీ కీ** – the unique number of each row. *ప్రతి row ని ప్రత్యేకంగా గుర్తించే నంబర్ (ఉదా: appointment id 25).*

**Foreign key / ఫారిన్ కీ** – a column that points to a row in another table (`appointment.doctor_id`). *మరో table లోని row కి లింక్ చేసే column. ఇది లేని doctor కి appointment ఇవ్వనివ్వదు.*

**One-to-one / one-to-many** – one user ↔ one patient profile; one doctor ↔ many appointments. *ఒక user కి ఒకే profile; ఒక doctor కి చాలా appointments.*

**Index** – a lookup structure so MySQL finds rows fast, like a book index. *పుస్తకంలో index లాగా, వెతకడం వేగంగా చేస్తుంది.*

**Transaction** – several database steps that all succeed or all fail. Rescheduling = check new slot + move booking; if any step fails nothing changes. *అన్నీ విజయవంతం లేదా ఏదీ కాదు.*

**Row lock (`select_for_update`)** – while one booking is being processed for a doctor, a second one waits. *ఒకరు బుకింగ్ చేస్తున్నప్పుడు మరొకరు వేచి ఉండాలి – double booking రాదు.*

**Unique constraint** – the database itself refuses two active bookings of the same slot, even if code has a bug. *Code లో తప్పు ఉన్నా database రెండో బుకింగ్ ని ఆపుతుంది.*

**Session cookie (HttpOnly)** – after login the server gives the browser a cookie that JavaScript cannot read, so stolen scripts cannot steal it. *JavaScript చదవలేని cookie – భద్రం.*

**CSRF** – another website tricking your logged-in browser into sending a request. Django requires a secret token header (`X-CSRFToken`) that other sites cannot know. *వేరే సైట్ మీ పేరుతో request పంపకుండా అడ్డుకునే టోకెన్.*

**Role-based permission** – the server checks the role on every API call (`IsAdminRole`, `IsPatient`). Hiding a button in React is only for looks. *Button దాచడం భద్రత కాదు; server లో తనిఖీ తప్పనిసరి.*

**Object-level isolation** – `get_queryset()` returns only the rows a user may see, so someone else's appointment is simply "404". *ఇతరుల data కనిపించదు.*

**Hashing** – passwords are stored as irreversible PBKDF2 hashes, never as text. *Password ని అసలు రూపంలో దాచరు.*

## Where to read the code first
1. `backend/appointments/services.py` – all booking rules
2. `backend/appointments/models.py` – the unique-slot trick
3. `backend/appointments/views.py` – who sees what
4. `frontend/src/api/client.js` – cookies + CSRF
5. `frontend/src/components/AppointmentForm.jsx` – booking UI
