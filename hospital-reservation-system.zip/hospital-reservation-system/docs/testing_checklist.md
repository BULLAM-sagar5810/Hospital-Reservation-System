# Manual end-to-end checklist
Run `python manage.py seed_data` first. Demo password for all accounts: `Demo@12345`.

**Public**
- [ ] Home loads, departments and featured doctors appear
- [ ] Doctor directory: search "rao", filter department, paginate
- [ ] Doctor details shows fee, qualifications and slots for a chosen date
**Patient** (`patient01@example.test`)
- [ ] Register a new patient (invalid email / short password / mismatch show errors)
- [ ] Login with wrong password shows an error; correct password opens the dashboard
- [ ] Book: doctor → date → slot → confirm; toast + notification appear; slot disappears for others
- [ ] Open a second browser (another patient) – the booked slot is not offered; forcing it via API → 409
- [ ] Reschedule to another slot; cancel with a reason; cancelled slot becomes available again
- [ ] An appointment starting in < 2 h has no cancel/reschedule buttons
- [ ] Edit profile; change password; log out and in with the new password
- [ ] Visiting `/admin` or `/doctor` as patient redirects away; API returns 403
**Doctor** (`dr.anita.rao@hospital.test`)
- [ ] Dashboard shows today's/upcoming; only own patients' names visible
- [ ] Accept/reject a pending request (set `APPOINTMENT_AUTO_CONFIRM=False` to create some)
- [ ] Complete / Missed only enabled once the appointment time has passed
- [ ] Add working hours (overlap rejected), add leave, pause "accept appointments"
**Admin** (`admin@hospital.test`)
- [ ] Dashboard statistics; add/edit/deactivate department; add doctor and log in as them
- [ ] Hide a doctor – disappears from public directory; deactivate a patient – cannot log in
- [ ] Search/filter appointments; cancel one
**Security**
- [ ] POST without `X-CSRFToken` while logged in → 403
- [ ] 25 rapid wrong logins → 429
- [ ] Patient A requesting patient B's appointment id → 404
