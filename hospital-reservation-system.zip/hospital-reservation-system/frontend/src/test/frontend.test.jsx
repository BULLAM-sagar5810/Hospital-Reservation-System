import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { vi } from 'vitest';

vi.mock('../api/services', () => ({
  authApi: { me: vi.fn(), login: vi.fn(), register: vi.fn(), logout: vi.fn(), changePassword: vi.fn() },
  departmentsApi: { list: vi.fn() },
  doctorsApi: { list: vi.fn(), availability: vi.fn() },
  appointmentsApi: { list: vi.fn(), create: vi.fn(), cancel: vi.fn() },
  patientsApi: {}, dashboardApi: {}, schedulesApi: {}, timeOffApi: {}, notificationsApi: {},
}));
vi.mock('../api/client', () => ({
  default: {}, refreshCsrf: vi.fn().mockResolvedValue('t'),
  errorMessage: (e) => e.response?.data?.error?.message || 'Something went wrong.',
  fieldErrors: () => ({}),
}));

import { appointmentsApi, authApi, departmentsApi, doctorsApi } from '../api/services';
import { AuthProvider } from '../context/AuthContext';
import { ToastProvider } from '../context/ToastContext';
import Register from '../pages/Register';
import Login from '../pages/Login';
import DoctorDirectory from '../pages/DoctorDirectory';
import BookAppointment from '../pages/patient/BookAppointment';
import MyAppointments from '../pages/patient/MyAppointments';
import { validateRegister } from '../utils/validators';

const wrap = (ui, path = '/') => render(
  <MemoryRouter initialEntries={[path]}><ToastProvider><AuthProvider>
    <Routes><Route path="*" element={ui} /></Routes>
  </AuthProvider></ToastProvider></MemoryRouter>);

const doctor = { id: 1, name: 'Anita Rao', department_id: 1, department_name: 'Cardiology', specialization: 'Heart', experience_years: 10, consultation_fee: '900.00', is_accepting_appointments: true };
const future = new Date(Date.now() + 5 * 86400000).toISOString();
const appt = { id: 7, doctor_id: 1, doctor_name: 'Anita Rao', department: 'Cardiology', start_datetime: future, end_datetime: future, status: 'CONFIRMED', reason_for_visit: '', can_cancel: true, can_reschedule: true };

beforeEach(() => { vi.clearAllMocks(); authApi.me.mockRejectedValue({ response: { status: 403 } }); departmentsApi.list.mockResolvedValue([{ id: 1, name: 'Cardiology' }]); });

describe('form validation', () => {
  it('validateRegister flags every bad field', () => {
    const e = validateRegister({ name: '', email: 'nope', phone: 'abc', password: '123', confirm_password: 'x' });
    expect(Object.keys(e).sort()).toEqual(['confirm_password', 'email', 'name', 'password', 'phone']);
  });
  it('register page shows clear errors and does not call the API', async () => {
    wrap(<Register />);
    await userEvent.click(screen.getByRole('button', { name: 'Register' }));
    expect(await screen.findByText('Full name is required.')).toBeInTheDocument();
    expect(screen.getByText('Enter a valid email address.')).toBeInTheDocument();
    expect(authApi.register).not.toHaveBeenCalled();
  });
  it('shows password mismatch', async () => {
    wrap(<Register />);
    await userEvent.type(screen.getByLabelText('Full name'), 'Test');
    await userEvent.type(screen.getByLabelText('Email'), 'a@b.co');
    await userEvent.type(screen.getByLabelText('Password'), 'Str0ngPass!');
    await userEvent.type(screen.getByLabelText('Confirm password'), 'different');
    await userEvent.click(screen.getByRole('button', { name: 'Register' }));
    expect(await screen.findByText('Passwords do not match.')).toBeInTheDocument();
  });
});

describe('login', () => {
  it('shows the server error for wrong credentials', async () => {
    authApi.login.mockRejectedValue({ response: { data: { error: { message: 'Incorrect email or password.' } } } });
    wrap(<Login />);
    await userEvent.type(screen.getByLabelText('Email'), 'a@b.co');
    await userEvent.type(screen.getByLabelText('Password'), 'wrong');
    await userEvent.click(screen.getByRole('button', { name: 'Log in' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('Incorrect email or password.');
  });
  it('requires both fields', async () => {
    wrap(<Login />);
    await userEvent.click(screen.getByRole('button', { name: 'Log in' }));
    expect(await screen.findByText('Email is required.')).toBeInTheDocument();
    expect(authApi.login).not.toHaveBeenCalled();
  });
});

describe('doctor directory', () => {
  it('shows a loading state, then doctor cards', async () => {
    doctorsApi.list.mockResolvedValue({ count: 1, results: [doctor] });
    wrap(<DoctorDirectory />);
    expect(screen.getByText('Loading doctors…')).toBeInTheDocument();
    expect(await screen.findByText('Dr. Anita Rao')).toBeInTheDocument();
  });
  it('searches by typing', async () => {
    doctorsApi.list.mockResolvedValue({ count: 1, results: [doctor] });
    wrap(<DoctorDirectory />);
    await screen.findByText('Dr. Anita Rao');
    await userEvent.type(screen.getByLabelText(/Search by name/), 'rao');
    await waitFor(() => expect(doctorsApi.list).toHaveBeenLastCalledWith(expect.objectContaining({ search: 'rao' })));
  });
  it('shows an empty state and an error state with retry', async () => {
    doctorsApi.list.mockResolvedValueOnce({ count: 0, results: [] });
    const { unmount } = wrap(<DoctorDirectory />);
    expect(await screen.findByText('No doctors found')).toBeInTheDocument();
    unmount();
    doctorsApi.list.mockRejectedValueOnce({}).mockResolvedValueOnce({ count: 1, results: [doctor] });
    wrap(<DoctorDirectory />);
    expect(await screen.findByRole('alert')).toHaveTextContent('Something went wrong.');
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByText('Dr. Anita Rao')).toBeInTheDocument();
  });
});

describe('booking flow', () => {
  it('picks a doctor, date and slot, then books', async () => {
    doctorsApi.list.mockResolvedValue({ count: 1, results: [doctor] });
    const start = new Date(Date.now() + 3 * 86400000).toISOString();
    doctorsApi.availability.mockResolvedValue({ slots: [{ start, end: start }] });
    appointmentsApi.create.mockResolvedValue({ ...appt, id: 99 });
    wrap(<BookAppointment />);
    await userEvent.selectOptions(await screen.findByLabelText('Doctor'), '1');
    const confirm = screen.getByRole('button', { name: 'Confirm booking' });
    expect(confirm).toBeDisabled();
    const date = screen.getByLabelText('Appointment date');
    await userEvent.type(date, new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10));
    const slot = await screen.findByRole('radio');
    await userEvent.click(slot);
    expect(screen.getByLabelText('Booking summary')).toBeInTheDocument();
    await userEvent.click(confirm);
    await waitFor(() => expect(appointmentsApi.create).toHaveBeenCalledWith(expect.objectContaining({ doctor_id: 1, start_datetime: start })));
    expect(await screen.findByText(/Booking confirmed! Appointment #99/)).toBeInTheDocument();
  });
  it('shows the server message when the slot was just taken', async () => {
    doctorsApi.list.mockResolvedValue({ count: 1, results: [doctor] });
    const start = new Date(Date.now() + 3 * 86400000).toISOString();
    doctorsApi.availability.mockResolvedValue({ slots: [{ start, end: start }] });
    appointmentsApi.create.mockRejectedValue({ response: { data: { error: { message: 'This slot has just been booked. Please choose another.' } } } });
    wrap(<BookAppointment />, '/book?doctor=1');
    await userEvent.type(await screen.findByLabelText('Appointment date'), new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10));
    await userEvent.click(await screen.findByRole('radio'));
    await userEvent.click(screen.getByRole('button', { name: 'Confirm booking' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('just been booked');
  });
});

describe('appointment list', () => {
  it('renders appointments with cancel / reschedule actions', async () => {
    appointmentsApi.list.mockResolvedValue({ count: 1, results: [appt] });
    wrap(<MyAppointments />);
    expect(await screen.findByText('Dr. Anita Rao')).toBeInTheDocument();
    expect(document.querySelector('.badge')).toHaveTextContent('Confirmed');
    expect(screen.getByRole('button', { name: 'Cancel' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Reschedule' })).toBeInTheDocument();
  });
  it('hides actions when not permitted and cancels through the confirmation dialog', async () => {
    appointmentsApi.list.mockResolvedValue({ count: 2, results: [{ ...appt, id: 8, can_cancel: false, can_reschedule: false }, appt] });
    appointmentsApi.cancel.mockResolvedValue({});
    wrap(<MyAppointments />);
    await screen.findAllByText('Dr. Anita Rao');
    expect(screen.getAllByRole('button', { name: 'Cancel' })).toHaveLength(1);
    await userEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    await userEvent.click(await screen.findByRole('button', { name: 'Yes, cancel it' }));
    await waitFor(() => expect(appointmentsApi.cancel).toHaveBeenCalledWith(7, ''));
  });
  it('shows empty state', async () => {
    appointmentsApi.list.mockResolvedValue({ count: 0, results: [] });
    wrap(<MyAppointments />);
    expect(await screen.findByText('No appointments here')).toBeInTheDocument();
  });
});
