import { useState } from 'react';
import SlotPicker from './SlotPicker';
import { formatDateTime, money } from '../utils/format';

/** Booking form: choose doctor -> date -> slot -> reason -> confirm. */
export default function AppointmentForm({ doctors, initialDoctorId = '', submitting, onSubmit }) {
  const [doctorId, setDoctorId] = useState(initialDoctorId);
  const [date, setDate] = useState('');
  const [slot, setSlot] = useState('');
  const [reason, setReason] = useState('');
  const doctor = doctors.find((d) => String(d.id) === String(doctorId));

  const submit = (e) => {
    e.preventDefault();
    if (doctor && slot) onSubmit({ doctor_id: doctor.id, start_datetime: slot, reason_for_visit: reason });
  };

  return (
    <form className="card form-card" onSubmit={submit} noValidate>
      <label className="field">
        <span>Doctor</span>
        <select value={doctorId} onChange={(e) => { setDoctorId(e.target.value); setSlot(''); }} required>
          <option value="">Select a doctor…</option>
          {doctors.map((d) => (
            <option key={d.id} value={d.id} disabled={!d.is_accepting_appointments}>
              Dr. {d.name} — {d.department_name}{d.is_accepting_appointments ? '' : ' (not accepting)'}
            </option>
          ))}
        </select>
      </label>
      {doctor && <SlotPicker doctorId={doctor.id} date={date} onDateChange={setDate} value={slot} onChange={setSlot} />}
      <label className="field">
        <span>Reason for visit (optional)</span>
        <textarea rows={3} maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)}
                  placeholder="Short note for the front desk. Do not include detailed medical history." />
      </label>
      {doctor && slot && (
        <dl className="summary" aria-label="Booking summary">
          <dt>Doctor</dt><dd>Dr. {doctor.name} ({doctor.department_name})</dd>
          <dt>When</dt><dd>{formatDateTime(slot)}</dd>
          <dt>Consultation fee</dt><dd>{money(doctor.consultation_fee)}</dd>
        </dl>
      )}
      <button className="btn btn-primary" type="submit" disabled={!doctor || !slot || submitting}>
        {submitting ? 'Booking…' : 'Confirm booking'}
      </button>
    </form>
  );
}
