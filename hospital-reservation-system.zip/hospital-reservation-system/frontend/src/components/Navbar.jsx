import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { homeFor, useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const toast = useToast();
  const close = () => setOpen(false);

  const onLogout = async () => {
    await logout();
    toast('success', 'You have been logged out.');
    close();
    navigate('/');
  };

  return (
    <header className="navbar">
      <div className="container nav-inner">
        <Link to="/" className="brand" onClick={close}><span aria-hidden="true">✚</span> CareBridge</Link>
        <button className="nav-toggle" aria-expanded={open} aria-label="Toggle menu" onClick={() => setOpen(!open)}>☰</button>
        <nav className={`nav-links ${open ? 'open' : ''}`} aria-label="Main">
          <NavLink to="/" end onClick={close}>Home</NavLink>
          <NavLink to="/doctors" onClick={close}>Find doctors</NavLink>
          {user ? (
            <>
              <NavLink to={homeFor(user.role)} onClick={close}>My dashboard</NavLink>
              <span className="nav-user">{user.name}</span>
              <button className="btn btn-outline btn-small" onClick={onLogout}>Log out</button>
            </>
          ) : (
            <>
              <NavLink to="/login" onClick={close}>Log in</NavLink>
              <Link className="btn btn-primary btn-small" to="/register" onClick={close}>Register</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
