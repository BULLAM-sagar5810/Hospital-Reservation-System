import { useEffect, useState } from 'react';
import { doctorsApi } from '../api/services';
import { errorMessage } from '../api/client';
import { formatTime, isoDay } from '../utils/format';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

/** Date input + the doctor's free slots loaded from the backend. value = chosen slot start (ISO). */
export default function SlotPicker({ doctorId, value, onChange, date, onDateChange }) {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!doctorId || !date) { setSlots([]); return undefined; }
    let alive = true;
    setLoading(true); setError('');
    doctorsApi.availability(doctorId, date)
      .then((d) => { if (alive) setSlots(d.slots); })
      .catch((e) => { if (alive) setError(errorMessage(e)); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [doctorId, date]);

  return (
    <div>
      <label className="field">
        <span>Appointment date</span>
        <input type="date" value={date} min={isoDay(0)} max={isoDay(60)} onChange={(e) => { onDateChange(e.target.value); onChange(''); }} />
      </label>
      {loading && <LoadingSpinner label="Loading available times…" />}
      <ErrorMessage message={error} />
      {!loading && !error && doctorId && date && slots.length === 0 && (
        <p className="muted">No free slots on this day. Try another date.</p>
      )}
      <div className="slots" role="radiogroup" aria-label="Available time slots">
        {slots.map((s) => (
          <button type="button" key={s.start} role="radio" aria-checked={value === s.start}
                  className={`slot ${value === s.start ? 'slot-on' : ''}`} onClick={() => onChange(s.start)}>
            {formatTime(s.start)}
          </button>
        ))}
      </div>
    </div>
  );
}
