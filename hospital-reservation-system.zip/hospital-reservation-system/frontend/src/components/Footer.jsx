import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div>
          <strong>CareBridge Hospital</strong>
          <p className="small">A fictional hospital used for a portfolio project. All people and data are made up.</p>
        </div>
        <div>
          <Link to="/doctors">Find a doctor</Link><br />
          <Link to="/register">Create account</Link>
        </div>
        <p className="small notice">
          This site manages appointments only. It does not provide medical advice or diagnosis. In an emergency, call your local emergency number.
        </p>
      </div>
    </footer>
  );
}
