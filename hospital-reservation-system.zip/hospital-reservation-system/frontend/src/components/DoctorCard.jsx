import { Link } from 'react-router-dom';
import { money } from '../utils/format';

export default function DoctorCard({ doctor }) {
  const initials = doctor.name.split(' ').map((p) => p[0]).slice(0, 2).join('');
  return (
    <article className="card doctor-card">
      <div className="avatar" aria-hidden="true">{initials}</div>
      <div className="doctor-info">
        <h3><Link to={`/doctors/${doctor.id}`}>Dr. {doctor.name}</Link></h3>
        <p className="muted">{doctor.specialization || doctor.department_name}</p>
        <p className="tag">{doctor.department_name}</p>
        <p className="muted small">{doctor.experience_years} yrs experience · Fee {money(doctor.consultation_fee)}</p>
        {!doctor.is_accepting_appointments && <p className="small warn">Not accepting appointments</p>}
      </div>
      <Link className="btn btn-primary btn-small" to={`/book?doctor=${doctor.id}`}>Book</Link>
    </article>
  );
}
