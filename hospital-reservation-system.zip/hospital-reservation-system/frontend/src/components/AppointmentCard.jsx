import { formatDate, formatTime } from '../utils/format';
import StatusBadge from './StatusBadge';

/** One appointment. `who` chooses what is shown as the main title (doctor for patients, patient for others). */
export default function AppointmentCard({ appointment: a, who = 'doctor', children }) {
  const title = who === 'doctor' ? `Dr. ${a.doctor_name}` : a.patient_name;
  return (
    <article className="card appt-card">
      <div className="appt-date">
        <strong>{formatDate(a.start_datetime)}</strong>
        <span>{formatTime(a.start_datetime)} – {formatTime(a.end_datetime)}</span>
      </div>
      <div className="appt-main">
        <h3>{title}</h3>
        <p className="muted small">
          #{a.id} · {a.department}{who !== 'doctor' && a.patient_email ? ` · ${a.patient_email}` : ''}
          {who !== 'doctor' && a.doctor_name ? ` · Dr. ${a.doctor_name}` : ''}
        </p>
        {a.reason_for_visit && <p className="small">Reason: {a.reason_for_visit}</p>}
        {a.cancellation_reason && <p className="small warn">Note: {a.cancellation_reason}</p>}
      </div>
      <div className="appt-side">
        <StatusBadge status={a.status} />
        <div className="actions">{children}</div>
      </div>
    </article>
  );
}
