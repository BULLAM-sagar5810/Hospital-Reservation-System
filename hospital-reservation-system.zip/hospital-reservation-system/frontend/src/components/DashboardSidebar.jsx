import { NavLink } from 'react-router-dom';

const LINKS = {
  PATIENT: [['/patient', 'Dashboard', true], ['/book', 'Book appointment'], ['/patient/appointments', 'My appointments'], ['/patient/profile', 'My profile']],
  DOCTOR: [['/doctor', 'Dashboard', true], ['/doctor/appointments', 'Appointments'], ['/doctor/schedule', 'Schedule & leave'], ['/doctor/profile', 'My profile']],
  ADMIN: [['/admin', 'Dashboard', true], ['/admin/appointments', 'Appointments'], ['/admin/doctors', 'Doctors'], ['/admin/departments', 'Departments'], ['/admin/patients', 'Patients']],
};

export default function DashboardSidebar({ role }) {
  return (
    <nav className="sidebar" aria-label="Dashboard">
      {(LINKS[role] || []).map(([to, label, end]) => (
        <NavLink key={to} to={to} end={end} className={({ isActive }) => (isActive ? 'active' : '')}>{label}</NavLink>
      ))}
      <NavLink to="/notifications" className={({ isActive }) => (isActive ? 'active' : '')}>Notifications</NavLink>
    </nav>
  );
}
