import { useState } from 'react';
import { appointmentsApi } from '../api/services';
import { errorMessage } from '../api/client';
import { useToast } from '../context/ToastContext';
import ConfirmationModal from './ConfirmationModal';

/** Doctor / admin status buttons for one appointment. */
export default function AppointmentActions({ appointment: a, onDone }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(null); // { status, title, danger }
  const started = new Date(a.start_datetime) <= new Date();

  const change = async (status, reason = '') => {
    setBusy(true);
    try {
      await appointmentsApi.update(a.id, { status, cancellation_reason: reason });
      toast('success', `Appointment #${a.id} updated.`);
      setConfirm(null);
      onDone();
    } catch (err) {
      toast('error', errorMessage(err));
      setConfirm(null);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      {a.status === 'PENDING' && (
        <>
          <button className="btn btn-primary btn-small" disabled={busy} onClick={() => change('CONFIRMED')}>Accept</button>
          <button className="btn btn-outline btn-small" onClick={() => setConfirm({ status: 'REJECTED', title: 'Reject this request?' })}>Reject</button>
        </>
      )}
      {a.status === 'CONFIRMED' && (
        <>
          <button className="btn btn-primary btn-small" disabled={busy || !started} title={started ? '' : 'Available after the appointment starts'} onClick={() => change('COMPLETED')}>Completed</button>
          <button className="btn btn-outline btn-small" disabled={busy || !started} onClick={() => change('NO_SHOW')}>Missed</button>
          <button className="btn btn-outline btn-small" onClick={() => setConfirm({ status: 'CANCELLED', title: 'Cancel this appointment?' })}>Cancel</button>
        </>
      )}
      <ConfirmationModal open={!!confirm} title={confirm?.title} danger askReason busy={busy}
        message="The patient will be notified." confirmLabel="Yes, continue"
        onCancel={() => setConfirm(null)} onConfirm={(reason) => change(confirm.status, reason)} />
    </>
  );
}
