import { useEffect, useState } from 'react';

/** Search box + department filter. Calls onChange({ search, department }) after the user pauses typing. */
export default function DoctorSearch({ departments = [], value, onChange }) {
  const [search, setSearch] = useState(value.search || '');
  useEffect(() => {
    const t = setTimeout(() => { if (search !== value.search) onChange({ ...value, search }); }, 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);
  return (
    <form className="search-bar" role="search" onSubmit={(e) => { e.preventDefault(); onChange({ ...value, search }); }}>
      <label className="field grow">
        <span>Search by name or specialization</span>
        <input type="search" placeholder="e.g. Rao, cardiology…" value={search} onChange={(e) => setSearch(e.target.value)} />
      </label>
      <label className="field">
        <span>Department</span>
        <select value={value.department || ''} onChange={(e) => onChange({ ...value, department: e.target.value })}>
          <option value="">All departments</option>
          {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      </label>
    </form>
  );
}
