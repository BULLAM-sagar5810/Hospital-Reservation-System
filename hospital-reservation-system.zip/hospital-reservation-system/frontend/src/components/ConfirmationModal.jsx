import { useEffect, useState } from 'react';

/** Accessible confirm dialog. Set `askReason` to also collect a short reason. */
export default function ConfirmationModal({ open, title, message, confirmLabel = 'Confirm', danger, askReason, busy, onConfirm, onCancel }) {
  const [reason, setReason] = useState('');
  useEffect(() => { if (open) setReason(''); }, [open]);
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && onCancel();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onCancel]);
  if (!open) return null;
  return (
    <div className="modal-backdrop" onClick={onCancel}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" onClick={(e) => e.stopPropagation()}>
        <h2 id="modal-title">{title}</h2>
        {message && <p>{message}</p>}
        {askReason && (
          <label className="field">
            <span>Reason (optional)</span>
            <input value={reason} maxLength={255} onChange={(e) => setReason(e.target.value)} />
          </label>
        )}
        <div className="modal-actions">
          <button className="btn btn-outline" onClick={onCancel} disabled={busy}>Go back</button>
          <button className={`btn ${danger ? 'btn-danger' : 'btn-primary'}`} disabled={busy} onClick={() => onConfirm(reason)}>
            {busy ? 'Please wait…' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
