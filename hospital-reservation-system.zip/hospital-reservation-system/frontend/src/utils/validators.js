export function validateRegister(v) {
  const e = {};
  if (!v.name.trim()) e.name = 'Full name is required.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) e.email = 'Enter a valid email address.';
  if (v.phone && !/^\+?[0-9 -]{7,15}$/.test(v.phone)) e.phone = 'Enter a valid phone number.';
  if (v.password.length < 8) e.password = 'Password must be at least 8 characters.';
  else if (/^\d+$/.test(v.password)) e.password = 'Password cannot be only numbers.';
  if (v.confirm_password !== v.password) e.confirm_password = 'Passwords do not match.';
  return e;
}
export function validateLogin(v) {
  const e = {};
  if (!v.email.trim()) e.email = 'Email is required.';
  if (!v.password) e.password = 'Password is required.';
  return e;
}
