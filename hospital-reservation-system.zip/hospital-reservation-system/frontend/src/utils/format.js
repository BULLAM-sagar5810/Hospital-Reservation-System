export const TZ = import.meta.env.VITE_TIME_ZONE || 'Asia/Kolkata';

export const formatDate = (iso) =>
  new Date(iso).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', timeZone: TZ });
export const formatTime = (iso) =>
  new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: TZ });
export const formatDateTime = (iso) => `${formatDate(iso)}, ${formatTime(iso)}`;

/** Today (or today + n days) as YYYY-MM-DD in the hospital time zone, for <input type="date">. */
export function isoDay(offsetDays = 0) {
  const d = new Date(Date.now() + offsetDays * 86400000);
  return d.toLocaleDateString('en-CA', { timeZone: TZ });
}

export const STATUS_LABELS = {
  PENDING: 'Pending', CONFIRMED: 'Confirmed', CANCELLED: 'Cancelled',
  COMPLETED: 'Completed', NO_SHOW: 'No show', REJECTED: 'Rejected',
};
export const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
export const money = (v) => `₹${Number(v).toLocaleString('en-IN')}`;
