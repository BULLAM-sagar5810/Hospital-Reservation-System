import { Outlet } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import DashboardSidebar from '../components/DashboardSidebar';
import { useAuth } from '../context/AuthContext';

export default function DashboardLayout() {
  const { user } = useAuth();
  return (
    <div className="app-shell">
      <a className="skip-link" href="#main">Skip to content</a>
      <Navbar />
      <div className="container dash-grid">
        <DashboardSidebar role={user?.role} />
        <main id="main" className="dash-main"><Outlet /></main>
      </div>
      <Footer />
    </div>
  );
}
