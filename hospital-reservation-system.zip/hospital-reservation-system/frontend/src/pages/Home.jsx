import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { departmentsApi, doctorsApi } from '../api/services';
import useFetch from '../hooks/useFetch';
import DoctorCard from '../components/DoctorCard';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';

export default function Home() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [department, setDepartment] = useState('');
  const depts = useFetch(() => departmentsApi.list(), []);
  const featured = useFetch(() => doctorsApi.list({ ordering: '-experience_years', page_size: 3 }), []);

  const go = (e) => {
    e.preventDefault();
    const q = new URLSearchParams();
    if (search) q.set('search', search);
    if (department) q.set('department', department);
    navigate(`/doctors?${q}`);
  };

  return (
    <>
      <section className="hero">
        <div className="container hero-inner">
          <div>
            <h1>See the right doctor, at a time that suits you.</h1>
            <p className="lead">Search our specialists, pick a free slot and receive your confirmation instantly. No phone queues.</p>
            <Link className="btn btn-primary" to="/doctors">Search doctors</Link>
          </div>
          <form className="card hero-form" onSubmit={go}>
            <h2>Find a doctor</h2>
            <label className="field"><span>Name or specialization</span>
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="e.g. Cardiology" /></label>
            <label className="field"><span>Department</span>
              <select value={department} onChange={(e) => setDepartment(e.target.value)}>
                <option value="">All departments</option>
                {(depts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select></label>
            <button className="btn btn-primary" type="submit">Search</button>
          </form>
        </div>
      </section>

      <section className="container section">
        <h2>Our departments</h2>
        {depts.loading && <LoadingSpinner />}
        <ErrorMessage message={depts.error} onRetry={depts.reload} />
        <div className="grid grid-3">
          {(depts.data || []).map((d) => (
            <Link key={d.id} className="card dept-card" to={`/doctors?department=${d.id}`}>
              <h3>{d.name}</h3>
              <p className="muted small">{d.description}</p>
              <span className="tag">{d.doctor_count} doctors</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="container section">
        <h2>Featured doctors</h2>
        {featured.loading && <LoadingSpinner />}
        <ErrorMessage message={featured.error} onRetry={featured.reload} />
        <div className="grid grid-3">
          {(featured.data?.results || []).map((d) => <DoctorCard key={d.id} doctor={d} />)}
        </div>
      </section>

      <section className="cta">
        <div className="container center">
          <h2>Ready to book?</h2>
          <p>Create a free account and book your appointment in under a minute.</p>
          <Link className="btn btn-light" to="/register">Create account</Link>
        </div>
      </section>
    </>
  );
}
