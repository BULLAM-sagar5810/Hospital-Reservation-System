import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { doctorsApi } from '../api/services';
import useFetch from '../hooks/useFetch';
import SlotPicker from '../components/SlotPicker';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import { money } from '../utils/format';

export default function DoctorDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: d, loading, error, reload } = useFetch(() => doctorsApi.get(id), [id]);
  const [date, setDate] = useState('');
  const [slot, setSlot] = useState('');

  if (loading) return <div className="container section"><LoadingSpinner /></div>;
  if (error) return <div className="container section"><ErrorMessage message={error} onRetry={reload} /><Link to="/doctors">Back to doctors</Link></div>;

  return (
    <div className="container section detail-grid">
      <section className="card">
        <div className="avatar big" aria-hidden="true">{d.name.split(' ').map((p) => p[0]).join('').slice(0, 2)}</div>
        <h1>Dr. {d.name}</h1>
        <p className="muted">{d.specialization}</p>
        <p><span className="tag">{d.department_name}</span></p>
        <dl className="summary">
          <dt>Qualifications</dt><dd>{d.qualifications || '—'}</dd>
          <dt>Experience</dt><dd>{d.experience_years} years</dd>
          <dt>Consultation fee</dt><dd>{money(d.consultation_fee)}</dd>
        </dl>
        {d.biography && <><h2>About</h2><p>{d.biography}</p></>}
      </section>
      <section className="card">
        <h2>Available slots</h2>
        {!d.is_accepting_appointments ? <p className="warn">This doctor is not accepting appointments right now.</p> : (
          <>
            <SlotPicker doctorId={d.id} date={date} onDateChange={setDate} value={slot} onChange={setSlot} />
            <button className="btn btn-primary" style={{ marginTop: '1rem' }} onClick={() => navigate(`/book?doctor=${d.id}`)}>
              Book appointment
            </button>
          </>
        )}
      </section>
    </div>
  );
}
