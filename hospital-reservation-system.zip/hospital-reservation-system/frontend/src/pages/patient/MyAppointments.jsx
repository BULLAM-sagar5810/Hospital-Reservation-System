import { useState } from 'react';
import { appointmentsApi } from '../../api/services';
import { errorMessage } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import AppointmentCard from '../../components/AppointmentCard';
import ConfirmationModal from '../../components/ConfirmationModal';
import SlotPicker from '../../components/SlotPicker';
import Pagination from '../../components/Pagination';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';
import EmptyState from '../../components/EmptyState';
import { STATUS_LABELS, formatDateTime } from '../../utils/format';

const TABS = { upcoming: { upcoming: 'true' }, history: { history: 'true' }, all: {} };

export default function MyAppointments() {
  const toast = useToast();
  const [tab, setTab] = useState('upcoming');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [cancelTarget, setCancelTarget] = useState(null);
  const [moveTarget, setMoveTarget] = useState(null);
  const [date, setDate] = useState('');
  const [slot, setSlot] = useState('');
  const [busy, setBusy] = useState(false);

  const { data, loading, error, reload } = useFetch(
    () => appointmentsApi.list({ ...TABS[tab], ...(status && { status }), page }), [tab, status, page]);

  const run = async (fn, okMsg) => {
    setBusy(true);
    try { await fn(); toast('success', okMsg); setCancelTarget(null); setMoveTarget(null); setSlot(''); reload(); }
    catch (err) { toast('error', errorMessage(err)); }
    finally { setBusy(false); }
  };

  return (
    <>
      <h1>My appointments</h1>
      <div className="toolbar">
        <div className="tabs" role="tablist">
          {Object.keys(TABS).map((t) => (
            <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? 'tab on' : 'tab'}
                    onClick={() => { setTab(t); setPage(1); }}>{t[0].toUpperCase() + t.slice(1)}</button>
          ))}
        </div>
        <label className="field inline"><span>Status</span>
          <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
            <option value="">Any</option>
            {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select></label>
      </div>

      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {!loading && !error && data?.results.length === 0 && <EmptyState title="No appointments here">Book one from the doctor directory.</EmptyState>}
      {(data?.results || []).map((a) => (
        <AppointmentCard key={a.id} appointment={a}>
          {a.can_reschedule && <button className="btn btn-outline btn-small" onClick={() => { setMoveTarget(a); setDate(''); setSlot(''); }}>Reschedule</button>}
          {a.can_cancel && <button className="btn btn-outline btn-small" onClick={() => setCancelTarget(a)}>Cancel</button>}
        </AppointmentCard>
      ))}
      {data && <Pagination page={page} count={data.count} onChange={setPage} />}

      <ConfirmationModal open={!!cancelTarget} danger askReason busy={busy} title="Cancel this appointment?"
        message={cancelTarget && `${formatDateTime(cancelTarget.start_datetime)} with Dr. ${cancelTarget.doctor_name}. The slot will be released.`}
        confirmLabel="Yes, cancel it" onCancel={() => setCancelTarget(null)}
        onConfirm={(reason) => run(() => appointmentsApi.cancel(cancelTarget.id, reason), 'Appointment cancelled.')} />

      {moveTarget && (
        <div className="modal-backdrop" onClick={() => setMoveTarget(null)}>
          <div className="modal" role="dialog" aria-modal="true" aria-label="Reschedule" onClick={(e) => e.stopPropagation()}>
            <h2>Reschedule appointment #{moveTarget.id}</h2>
            <p className="muted small">Currently {formatDateTime(moveTarget.start_datetime)} with Dr. {moveTarget.doctor_name}</p>
            <SlotPicker doctorId={moveTarget.doctor_id} date={date} onDateChange={setDate} value={slot} onChange={setSlot} />
            <div className="modal-actions">
              <button className="btn btn-outline" onClick={() => setMoveTarget(null)}>Close</button>
              <button className="btn btn-primary" disabled={!slot || busy}
                onClick={() => run(() => appointmentsApi.reschedule(moveTarget.id, slot), 'Appointment rescheduled.')}>
                {busy ? 'Saving…' : 'Confirm new time'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
