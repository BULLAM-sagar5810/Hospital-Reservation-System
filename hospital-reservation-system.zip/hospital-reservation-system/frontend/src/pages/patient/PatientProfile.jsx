import { useEffect, useState } from 'react';
import { authApi, patientsApi } from '../../api/services';
import { errorMessage, fieldErrors } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';

export default function PatientProfile() {
  const toast = useToast();
  const { setUser } = useAuth();
  const { data, loading, error, reload } = useFetch(() => patientsApi.me(), []);
  const [form, setForm] = useState(null);
  const [errors, setErrors] = useState({});
  const [pw, setPw] = useState({ current_password: '', new_password: '' });
  const [pwErrors, setPwErrors] = useState({});

  useEffect(() => { if (data) setForm({ name: data.name, phone: data.phone || '', date_of_birth: data.date_of_birth || '', address: data.address || '' }); }, [data]);

  const save = async (e) => {
    e.preventDefault();
    try {
      const body = { ...form, date_of_birth: form.date_of_birth || null };
      const updated = await patientsApi.updateMe(body);
      setUser((u) => ({ ...u, name: updated.name, phone: updated.phone }));
      setErrors({}); toast('success', 'Profile updated.'); reload();
    } catch (err) { setErrors(fieldErrors(err)); toast('error', errorMessage(err)); }
  };

  const changePw = async (e) => {
    e.preventDefault();
    try {
      await authApi.changePassword(pw);
      setPw({ current_password: '', new_password: '' }); setPwErrors({});
      toast('success', 'Password changed.');
    } catch (err) { setPwErrors(fieldErrors(err)); toast('error', errorMessage(err)); }
  };

  if (loading || !form) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} onRetry={reload} />;
  const input = (name, label, type = 'text') => (
    <label className="field"><span>{label}</span>
      <input type={type} value={form[name]} onChange={(e) => setForm({ ...form, [name]: e.target.value })} />
      {errors[name] && <small className="field-error">{errors[name]}</small>}</label>
  );

  return (
    <>
      <h1>My profile</h1>
      <form className="card form-card" onSubmit={save}>
        <label className="field"><span>Email (cannot be changed)</span><input value={data.email} disabled /></label>
        {input('name', 'Full name')}
        {input('phone', 'Phone number', 'tel')}
        {input('date_of_birth', 'Date of birth', 'date')}
        {input('address', 'Address')}
        <button className="btn btn-primary" type="submit">Save changes</button>
      </form>

      <form className="card form-card" onSubmit={changePw} style={{ marginTop: '1.5rem' }}>
        <h2>Change password</h2>
        <label className="field"><span>Current password</span>
          <input type="password" autoComplete="current-password" value={pw.current_password} onChange={(e) => setPw({ ...pw, current_password: e.target.value })} />
          {pwErrors.current_password && <small className="field-error">{pwErrors.current_password}</small>}</label>
        <label className="field"><span>New password</span>
          <input type="password" autoComplete="new-password" value={pw.new_password} onChange={(e) => setPw({ ...pw, new_password: e.target.value })} />
          {pwErrors.new_password && <small className="field-error">{pwErrors.new_password}</small>}</label>
        <button className="btn btn-outline" type="submit" disabled={!pw.current_password || !pw.new_password}>Update password</button>
      </form>
    </>
  );
}
