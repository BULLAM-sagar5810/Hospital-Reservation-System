import { Link } from 'react-router-dom';
import { dashboardApi } from '../../api/services';
import useFetch from '../../hooks/useFetch';
import { useAuth } from '../../context/AuthContext';
import AppointmentCard from '../../components/AppointmentCard';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';
import EmptyState from '../../components/EmptyState';

function Section({ title, items, empty }) {
  return (
    <section>
      <h2>{title}</h2>
      {items.length === 0 ? <EmptyState title={empty} /> : items.map((a) => <AppointmentCard key={a.id} appointment={a} />)}
    </section>
  );
}

export default function PatientDashboard() {
  const { user } = useAuth();
  const { data, loading, error, reload } = useFetch(() => dashboardApi.patient(), []);
  return (
    <>
      <div className="page-head">
        <h1>Hello, {user.name.split(' ')[0]}</h1>
        <Link className="btn btn-primary" to="/book">Book an appointment</Link>
      </div>
      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {data && (
        <>
          <div className="stats">
            <div className="stat"><b>{data.stats.UPCOMING}</b><span>Upcoming</span></div>
            <div className="stat"><b>{data.stats.COMPLETED}</b><span>Completed</span></div>
            <div className="stat"><b>{data.stats.CANCELLED}</b><span>Cancelled</span></div>
            <div className="stat"><b>{data.stats.TOTAL}</b><span>Total</span></div>
          </div>
          <Section title="Upcoming appointments" items={data.upcoming} empty="No upcoming appointments" />
          <Section title="Previous appointments" items={data.previous} empty="No previous appointments" />
          <Section title="Cancelled appointments" items={data.cancelled} empty="Nothing cancelled" />
        </>
      )}
    </>
  );
}
