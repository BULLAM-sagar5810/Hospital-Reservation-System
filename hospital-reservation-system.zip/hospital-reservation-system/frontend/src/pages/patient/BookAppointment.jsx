import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { appointmentsApi, doctorsApi } from '../../api/services';
import { errorMessage } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import AppointmentForm from '../../components/AppointmentForm';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';

export default function BookAppointment() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const doctors = useFetch(() => doctorsApi.list({ page_size: 100, ordering: 'user__name' }), []);

  const onSubmit = async (payload) => {
    setSubmitting(true); setError('');
    try {
      const appt = await appointmentsApi.create(payload);
      toast('success', appt.status === 'CONFIRMED'
        ? `Booking confirmed! Appointment #${appt.id} with Dr. ${appt.doctor_name}.`
        : `Request sent! Appointment #${appt.id} is waiting for the doctor's confirmation.`);
      navigate('/patient/appointments');
    } catch (err) {
      setError(errorMessage(err)); // e.g. "This slot has just been booked."
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <h1>Book an appointment</h1>
      {doctors.loading && <LoadingSpinner />}
      <ErrorMessage message={doctors.error} onRetry={doctors.reload} />
      <ErrorMessage message={error} />
      {doctors.data && (
        <AppointmentForm doctors={doctors.data.results} initialDoctorId={params.get('doctor') || ''}
                         submitting={submitting} onSubmit={onSubmit} />
      )}
    </>
  );
}
