import { useSearchParams } from 'react-router-dom';
import { departmentsApi, doctorsApi } from '../api/services';
import useFetch from '../hooks/useFetch';
import DoctorCard from '../components/DoctorCard';
import DoctorSearch from '../components/DoctorSearch';
import Pagination from '../components/Pagination';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';

export default function DoctorDirectory() {
  const [params, setParams] = useSearchParams();
  const filters = { search: params.get('search') || '', department: params.get('department') || '' };
  const page = Number(params.get('page') || 1);

  const depts = useFetch(() => departmentsApi.list(), []);
  const { data, loading, error, reload } = useFetch(
    () => doctorsApi.list({ ...(filters.search && { search: filters.search }), ...(filters.department && { department: filters.department }), page }),
    [filters.search, filters.department, page]);

  const update = (f, p = 1) => {
    const q = {};
    if (f.search) q.search = f.search;
    if (f.department) q.department = f.department;
    if (p > 1) q.page = p;
    setParams(q);
  };

  return (
    <div className="container section">
      <h1>Find a doctor</h1>
      <DoctorSearch departments={depts.data || []} value={filters} onChange={(f) => update(f)} />
      {loading && <LoadingSpinner label="Loading doctors…" />}
      <ErrorMessage message={error} onRetry={reload} />
      {!loading && !error && data?.results.length === 0 && (
        <EmptyState title="No doctors found">Try a different name or choose another department.</EmptyState>
      )}
      <div className="grid grid-3">{(data?.results || []).map((d) => <DoctorCard key={d.id} doctor={d} />)}</div>
      {data && <Pagination page={page} count={data.count} onChange={(p) => update(filters, p)} />}
    </div>
  );
}
