import { useState } from 'react';
import { departmentsApi, doctorsApi } from '../../api/services';
import { errorMessage, fieldErrors } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import Pagination from '../../components/Pagination';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';
import EmptyState from '../../components/EmptyState';
import { money } from '../../utils/format';

const BLANK = { new_name: '', email: '', phone: '', password: '', department_id: '', specialization: '', qualifications: '', experience_years: 0, consultation_fee: 0, biography: '' };

export default function AdminDoctors() {
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState(null); // null | 'new' | doctor object
  const [form, setForm] = useState(BLANK);
  const [errors, setErrors] = useState({});
  const depts = useFetch(() => departmentsApi.list(), []);
  const { data, loading, error, reload } = useFetch(() => doctorsApi.list({ ...(search && { search }), page }), [search, page]);

  const open = (d) => {
    setErrors({});
    if (d === 'new') setForm(BLANK);
    else setForm({ department_id: d.department_id, specialization: d.specialization, qualifications: d.qualifications, experience_years: d.experience_years, consultation_fee: d.consultation_fee, biography: d.biography });
    setEditing(d);
  };
  const save = async (e) => {
    e.preventDefault();
    try {
      if (editing === 'new') await doctorsApi.create(form); else await doctorsApi.update(editing.id, form);
      toast('success', editing === 'new' ? 'Doctor added.' : 'Doctor updated.');
      setEditing(null); reload();
    } catch (err) { setErrors(fieldErrors(err)); toast('error', errorMessage(err)); }
  };
  const toggle = async (d) => {
    try { await doctorsApi.update(d.id, { is_listed: !d.is_listed }); toast('success', d.is_listed ? 'Doctor hidden from the directory.' : 'Doctor listed.'); reload(); }
    catch (err) { toast('error', errorMessage(err)); }
  };
  const f = (name, label, type = 'text', extra = {}) => (
    <label className="field"><span>{label}</span>
      <input type={type} value={form[name]} onChange={(e) => setForm({ ...form, [name]: e.target.value })} {...extra} />
      {errors[name] && <small className="field-error">{errors[name]}</small>}</label>);

  return (
    <>
      <div className="page-head"><h1>Doctors</h1><button className="btn btn-primary" onClick={() => open('new')}>Add doctor</button></div>
      {editing && (
        <form className="card form-card" onSubmit={save}>
          <h2>{editing === 'new' ? 'Add doctor' : `Edit Dr. ${editing.name}`}</h2>
          {editing === 'new' && <>{f('new_name', 'Full name', 'text', { required: true })}{f('email', 'Email (login)', 'email', { required: true })}{f('phone', 'Phone')}{f('password', 'Temporary password', 'password', { required: true, autoComplete: 'new-password' })}</>}
          <label className="field"><span>Department</span>
            <select required value={form.department_id} onChange={(e) => setForm({ ...form, department_id: e.target.value })}>
              <option value="">Select…</option>{(depts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
            {errors.department_id && <small className="field-error">{errors.department_id}</small>}</label>
          {f('specialization', 'Specialization')}{f('qualifications', 'Qualifications')}
          {f('experience_years', 'Years of experience', 'number', { min: 0 })}{f('consultation_fee', 'Consultation fee (₹)', 'number', { min: 0, step: '0.01' })}
          <label className="field"><span>Biography</span><textarea rows={3} value={form.biography} onChange={(e) => setForm({ ...form, biography: e.target.value })} /></label>
          <div className="actions"><button className="btn btn-primary" type="submit">Save</button>
            <button type="button" className="btn btn-outline" onClick={() => setEditing(null)}>Cancel</button></div>
        </form>
      )}
      <label className="field"><span>Search doctors</span>
        <input type="search" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} /></label>
      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {!loading && data?.results.length === 0 && <EmptyState title="No doctors found" />}
      {data?.results.length > 0 && (
        <div className="table-wrap"><table>
          <thead><tr><th>Name</th><th>Department</th><th>Fee</th><th>Listing</th><th /></tr></thead>
          <tbody>{data.results.map((d) => (
            <tr key={d.id}><td>Dr. {d.name}</td><td>{d.department_name}</td><td>{money(d.consultation_fee)}</td>
              <td>{d.is_listed ? 'Listed' : 'Hidden'}</td>
              <td className="actions"><button className="btn btn-outline btn-small" onClick={() => open(d)}>Edit</button>
                <button className="btn btn-outline btn-small" onClick={() => toggle(d)}>{d.is_listed ? 'Deactivate' : 'Activate'}</button></td></tr>))}
          </tbody></table></div>
      )}
      {data && <Pagination page={page} count={data.count} onChange={setPage} />}
    </>
  );
}
