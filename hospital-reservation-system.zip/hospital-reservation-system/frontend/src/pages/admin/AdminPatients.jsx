import { useState } from 'react';
import { patientsApi } from '../../api/services';
import { errorMessage } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import Pagination from '../../components/Pagination';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';
import EmptyState from '../../components/EmptyState';

export default function AdminPatients() {
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useFetch(() => patientsApi.list({ ...(search && { search }), page }), [search, page]);
  const toggle = async (p) => {
    try { await patientsApi.update(p.id, { is_active: !p.is_active }); toast('success', p.is_active ? 'Account deactivated.' : 'Account activated.'); reload(); }
    catch (err) { toast('error', errorMessage(err)); }
  };
  return (
    <>
      <h1>Patient accounts</h1>
      <label className="field"><span>Search by name, email or phone</span>
        <input type="search" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} /></label>
      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {!loading && data?.results.length === 0 && <EmptyState title="No patients found" />}
      {data?.results.length > 0 && (
        <div className="table-wrap"><table>
          <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Status</th><th /></tr></thead>
          <tbody>{data.results.map((p) => (
            <tr key={p.id}><td>{p.name}</td><td>{p.email}</td><td>{p.phone || '—'}</td>
              <td>{p.is_active ? 'Active' : 'Deactivated'}</td>
              <td><button className="btn btn-outline btn-small" onClick={() => toggle(p)}>{p.is_active ? 'Deactivate' : 'Activate'}</button></td></tr>))}
          </tbody></table></div>
      )}
      {data && <Pagination page={page} count={data.count} onChange={setPage} />}
    </>
  );
}
