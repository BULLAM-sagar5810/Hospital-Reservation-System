import { useState } from 'react';
import { departmentsApi } from '../../api/services';
import { errorMessage, fieldErrors } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import ConfirmationModal from '../../components/ConfirmationModal';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';

export default function AdminDepartments() {
  const toast = useToast();
  const { data, loading, error, reload } = useFetch(() => departmentsApi.list(), []);
  const [form, setForm] = useState({ id: null, name: '', description: '' });
  const [errors, setErrors] = useState({});
  const [deleting, setDeleting] = useState(null);

  const save = async (e) => {
    e.preventDefault();
    try {
      if (form.id) await departmentsApi.update(form.id, { name: form.name, description: form.description });
      else await departmentsApi.create({ name: form.name, description: form.description });
      toast('success', form.id ? 'Department updated.' : 'Department added.');
      setForm({ id: null, name: '', description: '' }); setErrors({}); reload();
    } catch (err) { setErrors(fieldErrors(err)); toast('error', errorMessage(err)); }
  };
  const run = async (fn, msg) => { try { await fn(); toast('success', msg); reload(); } catch (err) { toast('error', errorMessage(err)); } finally { setDeleting(null); } };

  return (
    <>
      <h1>Departments</h1>
      <form className="card form-card" onSubmit={save}>
        <h2>{form.id ? 'Edit department' : 'Add department'}</h2>
        <label className="field"><span>Name</span><input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          {errors.name && <small className="field-error">{errors.name}</small>}</label>
        <label className="field"><span>Description</span><textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
        <div className="actions">
          <button className="btn btn-primary" type="submit">{form.id ? 'Save' : 'Add department'}</button>
          {form.id && <button type="button" className="btn btn-outline" onClick={() => setForm({ id: null, name: '', description: '' })}>Cancel edit</button>}
        </div>
      </form>
      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {data && (
        <div className="table-wrap"><table>
          <thead><tr><th>Name</th><th>Description</th><th>Doctors</th><th>Status</th><th /></tr></thead>
          <tbody>{data.map((d) => (
            <tr key={d.id}><td>{d.name}</td><td>{d.description}</td><td>{d.doctor_count}</td><td>{d.is_active ? 'Active' : 'Inactive'}</td>
              <td className="actions">
                <button className="btn btn-outline btn-small" onClick={() => setForm({ id: d.id, name: d.name, description: d.description })}>Edit</button>
                <button className="btn btn-outline btn-small" onClick={() => run(() => departmentsApi.update(d.id, { is_active: !d.is_active }), 'Status changed.')}>{d.is_active ? 'Deactivate' : 'Activate'}</button>
                <button className="btn btn-outline btn-small" onClick={() => setDeleting(d)}>Delete</button></td></tr>))}
          </tbody></table></div>
      )}
      <ConfirmationModal open={!!deleting} danger title="Delete department?" confirmLabel="Delete"
        message={deleting && `Delete ${deleting.name}? Departments that still have doctors cannot be deleted - deactivate them instead.`}
        onCancel={() => setDeleting(null)} onConfirm={() => run(() => departmentsApi.remove(deleting.id), 'Department deleted.')} />
    </>
  );
}
