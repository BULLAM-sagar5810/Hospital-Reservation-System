import { dashboardApi } from '../../api/services';
import useFetch from '../../hooks/useFetch';
import AppointmentCard from '../../components/AppointmentCard';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';
import { STATUS_LABELS } from '../../utils/format';

function Bars({ rows, labelKey = 'name' }) {
  const max = Math.max(1, ...rows.map((r) => r.total));
  return (
    <ul className="bars">
      {rows.map((r) => (
        <li key={r[labelKey]}><span>{r[labelKey]}</span>
          <div className="bar"><i style={{ width: `${(r.total / max) * 100}%` }} /></div><b>{r.total}</b></li>))}
    </ul>
  );
}

export default function AdminDashboard() {
  const { data: d, loading, error, reload } = useFetch(() => dashboardApi.admin(), []);
  return (
    <>
      <h1>Admin dashboard</h1>
      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {d && (
        <>
          <div className="stats">
            <div className="stat"><b>{d.total_patients}</b><span>Patients</span></div>
            <div className="stat"><b>{d.total_active_doctors}</b><span>Active doctors</span></div>
            <div className="stat"><b>{d.total_appointments}</b><span>Appointments</span></div>
            <div className="stat"><b>{d.pending_appointments}</b><span>Pending requests</span></div>
            <div className="stat"><b>{d.cancelled_appointments}</b><span>Cancelled ({d.cancellation_rate}%)</span></div>
          </div>
          <div className="grid grid-2">
            <section className="card"><h2>Bookings by department</h2><Bars rows={d.by_department} /></section>
            <section className="card"><h2>Most booked doctors</h2><Bars rows={d.top_doctors} /></section>
          </div>
          <section className="card">
            <h2>Appointments by status</h2>
            <ul className="chips">{Object.entries(d.status_counts).map(([k, v]) => <li key={k}>{STATUS_LABELS[k]}: <b>{v}</b></li>)}</ul>
          </section>
          <h2>Recent appointments</h2>
          {d.recent.map((a) => <AppointmentCard key={a.id} appointment={a} who="admin" />)}
        </>
      )}
    </>
  );
}
