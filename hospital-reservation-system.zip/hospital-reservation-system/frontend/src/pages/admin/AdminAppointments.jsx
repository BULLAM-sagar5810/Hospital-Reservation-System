import { useState } from 'react';
import { appointmentsApi } from '../../api/services';
import useFetch from '../../hooks/useFetch';
import AppointmentCard from '../../components/AppointmentCard';
import AppointmentActions from '../../components/AppointmentActions';
import Pagination from '../../components/Pagination';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';
import EmptyState from '../../components/EmptyState';
import { STATUS_LABELS } from '../../utils/format';

export default function AdminAppointments() {
  const [f, setF] = useState({ search: '', status: '', date: '' });
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useFetch(
    () => appointmentsApi.list({ ...(f.search && { search: f.search }), ...(f.status && { status: f.status }), ...(f.date && { date: f.date }), page }),
    [f.search, f.status, f.date, page]);
  const set = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setPage(1); };
  return (
    <>
      <h1>Appointment management</h1>
      <div className="toolbar">
        <label className="field grow"><span>Search (patient, doctor or ID)</span><input type="search" value={f.search} onChange={set('search')} /></label>
        <label className="field inline"><span>Status</span>
          <select value={f.status} onChange={set('status')}><option value="">Any</option>
            {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
        <label className="field inline"><span>Date</span><input type="date" value={f.date} onChange={set('date')} /></label>
      </div>
      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {!loading && !error && data?.results.length === 0 && <EmptyState title="No appointments match" />}
      {(data?.results || []).map((a) => (
        <AppointmentCard key={a.id} appointment={a} who="admin"><AppointmentActions appointment={a} onDone={reload} /></AppointmentCard>))}
      {data && <Pagination page={page} count={data.count} onChange={setPage} />}
    </>
  );
}
