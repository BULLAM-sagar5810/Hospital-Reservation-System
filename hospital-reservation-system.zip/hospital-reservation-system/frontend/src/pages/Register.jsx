import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { errorMessage, fieldErrors } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { validateRegister } from '../utils/validators';
import ErrorMessage from '../components/ErrorMessage';

const FIELDS = [
  ['name', 'Full name', 'text', 'name'],
  ['email', 'Email', 'email', 'email'],
  ['phone', 'Phone number', 'tel', 'tel'],
  ['password', 'Password', 'password', 'new-password'],
  ['confirm_password', 'Confirm password', 'password', 'new-password'],
];

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [values, setValues] = useState({ name: '', email: '', phone: '', password: '', confirm_password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    const v = validateRegister(values);
    setErrors(v);
    setServerError('');
    if (Object.keys(v).length) return;
    setBusy(true);
    try {
      await register(values);
      toast('success', 'Account created. Welcome!');
      navigate('/patient', { replace: true });
    } catch (err) {
      setErrors(fieldErrors(err));
      setServerError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container section narrow">
      <form className="card form-card" onSubmit={submit} noValidate>
        <h1>Create your account</h1>
        <ErrorMessage message={serverError} />
        {FIELDS.map(([name, label, type, auto]) => (
          <label className="field" key={name}>
            <span>{label}</span>
            <input name={name} type={type} autoComplete={auto} value={values[name]} aria-invalid={!!errors[name]}
                   onChange={(e) => setValues({ ...values, [name]: e.target.value })} />
            {errors[name] && <small className="field-error">{errors[name]}</small>}
          </label>
        ))}
        <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? 'Creating…' : 'Register'}</button>
        <p className="muted small">Already registered? <Link to="/login">Log in</Link></p>
      </form>
    </div>
  );
}
