import { dashboardApi } from '../../api/services';
import useFetch from '../../hooks/useFetch';
import AppointmentCard from '../../components/AppointmentCard';
import AppointmentActions from '../../components/AppointmentActions';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';
import EmptyState from '../../components/EmptyState';
import { DAYS } from '../../utils/format';

export default function DoctorDashboard() {
  const { data, loading, error, reload } = useFetch(() => dashboardApi.doctor(), []);
  const list = (items, empty) => items.length === 0 ? <EmptyState title={empty} /> : items.map((a) => (
    <AppointmentCard key={a.id} appointment={a} who="patient"><AppointmentActions appointment={a} onDone={reload} /></AppointmentCard>));
  return (
    <>
      <h1>Doctor dashboard</h1>
      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {data && (
        <>
          {!data.is_accepting_appointments && <div className="alert alert-warn">You are currently not accepting new appointments (change this under Schedule &amp; leave).</div>}
          <div className="stats">
            <div className="stat"><b>{data.today.length}</b><span>Today</span></div>
            <div className="stat"><b>{data.pending_requests}</b><span>Pending requests</span></div>
            <div className="stat"><b>{data.stats.CONFIRMED}</b><span>Confirmed</span></div>
            <div className="stat"><b>{data.stats.COMPLETED}</b><span>Completed</span></div>
          </div>
          <h2>Today's appointments</h2>
          {list(data.today, 'No appointments today')}
          <h2>Upcoming</h2>
          {list(data.upcoming, 'No upcoming appointments')}
          <h2>Weekly schedule</h2>
          {data.schedule.length === 0 ? <EmptyState title="No schedule set">Add working hours under Schedule &amp; leave.</EmptyState> : (
            <ul className="plain-list">{data.schedule.map((s) => (
              <li key={s.id} className="card note">{DAYS[s.day_of_week]}: {s.start_time.slice(0, 5)} – {s.end_time.slice(0, 5)} ({s.slot_duration_minutes} min slots)</li>))}</ul>
          )}
        </>
      )}
    </>
  );
}
