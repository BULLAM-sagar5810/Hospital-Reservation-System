import { useEffect, useState } from 'react';
import { doctorsApi } from '../../api/services';
import { errorMessage } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';

export default function DoctorProfilePage() {
  const { user } = useAuth();
  const toast = useToast();
  const { data, loading, error, reload } = useFetch(() => doctorsApi.get(user.doctor_profile_id), []);
  const [form, setForm] = useState(null);
  useEffect(() => { if (data) setForm({ specialization: data.specialization, qualifications: data.qualifications, experience_years: data.experience_years, biography: data.biography }); }, [data]);

  if (loading || !form) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} onRetry={reload} />;
  const save = async (e) => {
    e.preventDefault();
    try { await doctorsApi.update(data.id, form); toast('success', 'Profile updated.'); reload(); }
    catch (err) { toast('error', errorMessage(err)); }
  };
  const text = (name, label) => (
    <label className="field"><span>{label}</span>
      <input value={form[name]} onChange={(e) => setForm({ ...form, [name]: e.target.value })} /></label>);
  return (
    <>
      <h1>My professional profile</h1>
      <p className="muted">Department and consultation fee are managed by the hospital administrator.</p>
      <form className="card form-card" onSubmit={save}>
        <label className="field"><span>Department</span><input disabled value={data.department_name} /></label>
        {text('specialization', 'Specialization')}
        {text('qualifications', 'Qualifications')}
        <label className="field"><span>Years of experience</span>
          <input type="number" min="0" max="70" value={form.experience_years} onChange={(e) => setForm({ ...form, experience_years: Number(e.target.value) })} /></label>
        <label className="field"><span>Biography</span>
          <textarea rows={5} value={form.biography} onChange={(e) => setForm({ ...form, biography: e.target.value })} /></label>
        <button className="btn btn-primary" type="submit">Save changes</button>
      </form>
    </>
  );
}
