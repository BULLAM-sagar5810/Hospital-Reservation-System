import { useState } from 'react';
import { doctorsApi, schedulesApi, timeOffApi } from '../../api/services';
import { errorMessage } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';
import EmptyState from '../../components/EmptyState';
import { DAYS, formatDateTime } from '../../utils/format';

export default function DoctorSchedule() {
  const { user } = useAuth();
  const toast = useToast();
  const doctor = useFetch(() => doctorsApi.get(user.doctor_profile_id), []);
  const schedules = useFetch(() => schedulesApi.list(), []);
  const leave = useFetch(() => timeOffApi.list(), []);
  const [sch, setSch] = useState({ day_of_week: 0, start_time: '09:00', end_time: '13:00', slot_duration_minutes: 30 });
  const [off, setOff] = useState({ start_datetime: '', end_datetime: '', reason: '' });

  const act = async (fn, msg, reload) => {
    try { await fn(); toast('success', msg); reload(); } catch (err) { toast('error', errorMessage(err)); }
  };

  return (
    <>
      <h1>Schedule &amp; leave</h1>
      <ErrorMessage message={doctor.error || schedules.error || leave.error} />
      {doctor.loading ? <LoadingSpinner /> : doctor.data && (
        <label className="card toggle-row">
          <input type="checkbox" checked={doctor.data.is_accepting_appointments}
            onChange={(e) => act(() => doctorsApi.update(doctor.data.id, { is_accepting_appointments: e.target.checked }),
              e.target.checked ? 'You are accepting appointments.' : 'New bookings are paused.', doctor.reload)} />
          <span>Accept new appointments</span>
        </label>
      )}

      <h2>Weekly working hours</h2>
      {schedules.loading && <LoadingSpinner />}
      {schedules.data?.length === 0 && <EmptyState title="No working hours yet" />}
      <ul className="plain-list">
        {(schedules.data || []).map((s) => (
          <li key={s.id} className="card note row">
            <span>{DAYS[s.day_of_week]} {s.start_time.slice(0, 5)}–{s.end_time.slice(0, 5)} · {s.slot_duration_minutes} min {s.is_active ? '' : '(off)'}</span>
            <span className="actions">
              <button className="btn btn-outline btn-small" onClick={() => act(() => schedulesApi.update(s.id, { is_active: !s.is_active }), 'Schedule updated.', schedules.reload)}>{s.is_active ? 'Disable' : 'Enable'}</button>
              <button className="btn btn-outline btn-small" onClick={() => act(() => schedulesApi.remove(s.id), 'Schedule removed.', schedules.reload)}>Delete</button>
            </span>
          </li>))}
      </ul>
      <form className="card form-card row-form" onSubmit={(e) => { e.preventDefault(); act(() => schedulesApi.create(sch), 'Working hours added.', schedules.reload); }}>
        <label className="field"><span>Day</span>
          <select value={sch.day_of_week} onChange={(e) => setSch({ ...sch, day_of_week: Number(e.target.value) })}>
            {DAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}</select></label>
        <label className="field"><span>From</span><input type="time" value={sch.start_time} onChange={(e) => setSch({ ...sch, start_time: e.target.value })} /></label>
        <label className="field"><span>To</span><input type="time" value={sch.end_time} onChange={(e) => setSch({ ...sch, end_time: e.target.value })} /></label>
        <label className="field"><span>Slot (min)</span><input type="number" min="5" max="240" value={sch.slot_duration_minutes} onChange={(e) => setSch({ ...sch, slot_duration_minutes: Number(e.target.value) })} /></label>
        <button className="btn btn-primary" type="submit">Add hours</button>
      </form>

      <h2>Leave / unavailable periods</h2>
      {leave.data?.length === 0 && <EmptyState title="No leave planned" />}
      <ul className="plain-list">
        {(leave.data || []).map((l) => (
          <li key={l.id} className="card note row">
            <span>{formatDateTime(l.start_datetime)} → {formatDateTime(l.end_datetime)} {l.reason && `· ${l.reason}`}</span>
            <button className="btn btn-outline btn-small" onClick={() => act(() => timeOffApi.remove(l.id), 'Leave removed.', leave.reload)}>Remove</button>
          </li>))}
      </ul>
      <form className="card form-card row-form" onSubmit={(e) => {
        e.preventDefault();
        act(() => timeOffApi.create({ ...off, start_datetime: new Date(off.start_datetime).toISOString(), end_datetime: new Date(off.end_datetime).toISOString() }), 'Leave added.', leave.reload);
      }}>
        <label className="field"><span>From</span><input type="datetime-local" required value={off.start_datetime} onChange={(e) => setOff({ ...off, start_datetime: e.target.value })} /></label>
        <label className="field"><span>To</span><input type="datetime-local" required value={off.end_datetime} onChange={(e) => setOff({ ...off, end_datetime: e.target.value })} /></label>
        <label className="field grow"><span>Reason</span><input value={off.reason} onChange={(e) => setOff({ ...off, reason: e.target.value })} /></label>
        <button className="btn btn-primary" type="submit">Add leave</button>
      </form>
      <p className="muted small">Existing bookings are not cancelled automatically when you add leave. Review them under Appointments.</p>
    </>
  );
}
