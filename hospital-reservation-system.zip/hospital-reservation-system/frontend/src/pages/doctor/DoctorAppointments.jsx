import { useState } from 'react';
import { appointmentsApi } from '../../api/services';
import useFetch from '../../hooks/useFetch';
import AppointmentCard from '../../components/AppointmentCard';
import AppointmentActions from '../../components/AppointmentActions';
import Pagination from '../../components/Pagination';
import LoadingSpinner from '../../components/LoadingSpinner';
import ErrorMessage from '../../components/ErrorMessage';
import EmptyState from '../../components/EmptyState';
import { STATUS_LABELS } from '../../utils/format';

export default function DoctorAppointments() {
  const [filters, setFilters] = useState({ date: '', status: '' });
  const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useFetch(
    () => appointmentsApi.list({ ...(filters.date && { date: filters.date }), ...(filters.status && { status: filters.status }), page }),
    [filters.date, filters.status, page]);
  const set = (k) => (e) => { setFilters({ ...filters, [k]: e.target.value }); setPage(1); };

  return (
    <>
      <h1>Appointments</h1>
      <div className="toolbar">
        <label className="field inline"><span>Date</span><input type="date" value={filters.date} onChange={set('date')} /></label>
        <label className="field inline"><span>Status</span>
          <select value={filters.status} onChange={set('status')}>
            <option value="">Any</option>
            {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select></label>
        {(filters.date || filters.status) && <button className="btn btn-outline btn-small" onClick={() => setFilters({ date: '', status: '' })}>Clear</button>}
      </div>
      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {!loading && !error && data?.results.length === 0 && <EmptyState title="No appointments match" />}
      {(data?.results || []).map((a) => (
        <AppointmentCard key={a.id} appointment={a} who="patient"><AppointmentActions appointment={a} onDone={reload} /></AppointmentCard>
      ))}
      {data && <Pagination page={page} count={data.count} onChange={setPage} />}
    </>
  );
}
