import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { errorMessage } from '../api/client';
import { homeFor, useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { validateLogin } from '../utils/validators';
import ErrorMessage from '../components/ErrorMessage';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();
  const [values, setValues] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [busy, setBusy] = useState(false);

  const change = (e) => setValues({ ...values, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const v = validateLogin(values);
    setErrors(v);
    setServerError('');
    if (Object.keys(v).length) return;
    setBusy(true);
    try {
      const user = await login(values);
      toast('success', `Welcome back, ${user.name}!`);
      navigate(location.state?.from || homeFor(user.role), { replace: true });
    } catch (err) {
      setServerError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container section narrow">
      <form className="card form-card" onSubmit={submit} noValidate>
        <h1>Log in</h1>
        <ErrorMessage message={serverError} />
        <label className="field">
          <span>Email</span>
          <input name="email" type="email" autoComplete="username" value={values.email} onChange={change} aria-invalid={!!errors.email} />
          {errors.email && <small className="field-error">{errors.email}</small>}
        </label>
        <label className="field">
          <span>Password</span>
          <input name="password" type="password" autoComplete="current-password" value={values.password} onChange={change} aria-invalid={!!errors.password} />
          {errors.password && <small className="field-error">{errors.password}</small>}
        </label>
        <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? 'Logging in…' : 'Log in'}</button>
        <p className="muted small">New patient? <Link to="/register">Create an account</Link></p>
      </form>
    </div>
  );
}
