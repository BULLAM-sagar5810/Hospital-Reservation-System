import { notificationsApi } from '../api/services';
import useFetch from '../hooks/useFetch';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';
import { formatDateTime } from '../utils/format';

export default function Notifications() {
  const { data, loading, error, reload } = useFetch(() => notificationsApi.list(), []);
  const items = data?.results || [];
  return (
    <>
      <div className="page-head">
        <h1>Notifications</h1>
        {items.some((n) => !n.is_read) && (
          <button className="btn btn-outline btn-small" onClick={() => notificationsApi.readAll().then(reload)}>Mark all as read</button>
        )}
      </div>
      {loading && <LoadingSpinner />}
      <ErrorMessage message={error} onRetry={reload} />
      {!loading && !error && items.length === 0 && <EmptyState title="No notifications yet" />}
      <ul className="plain-list">
        {items.map((n) => (
          <li key={n.id} className={`card note ${n.is_read ? '' : 'unread'}`}>
            <p>{n.message}</p>
            <span className="muted small">{formatDateTime(n.created_at)}</span>
          </li>
        ))}
      </ul>
    </>
  );
}
