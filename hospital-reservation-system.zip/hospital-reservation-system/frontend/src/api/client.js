import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  withCredentials: true, // send the HttpOnly session cookie
});

// --- CSRF -----------------------------------------------------------------
// Django wants the CSRF token in a header for every unsafe request. We fetch it from
// /auth/csrf/ (works even when frontend and API live on different domains) and keep it in memory.
let csrfToken = null;
export async function refreshCsrf() {
  const { data } = await api.get('/auth/csrf/');
  csrfToken = data.csrfToken;
  return csrfToken;
}

api.interceptors.request.use(async (config) => {
  const method = (config.method || 'get').toLowerCase();
  if (!['get', 'head', 'options'].includes(method)) {
    if (!csrfToken) await refreshCsrf();
    config.headers['X-CSRFToken'] = csrfToken;
  }
  return config;
});

// If the token went stale (for example after login) fetch a new one and retry once.
api.interceptors.response.use(undefined, async (error) => {
  const { config, response } = error;
  const message = response?.data?.error?.message || '';
  if (response?.status === 403 && message.includes('CSRF') && config && !config._retried) {
    config._retried = true;
    await refreshCsrf();
    config.headers['X-CSRFToken'] = csrfToken;
    return api(config);
  }
  return Promise.reject(error);
});

/** Human readable message from our consistent {"error": {...}} response shape. */
export function errorMessage(err, fallback = 'Something went wrong. Please try again.') {
  if (!err.response) return 'Cannot reach the server. Check your connection and try again.';
  const e = err.response.data?.error;
  if (e?.code === 'validation_error' && e.details) {
    const first = Object.values(e.details).flat()[0];
    return typeof first === 'string' ? first : e.message;
  }
  return e?.message || fallback;
}

/** Field level errors: { email: "…", password: "…" } for showing under inputs. */
export function fieldErrors(err) {
  const d = err.response?.data?.error?.details;
  if (!d || typeof d !== 'object') return {};
  return Object.fromEntries(Object.entries(d).map(([k, v]) => [k, Array.isArray(v) ? v.join(' ') : String(v)]));
}

export default api;
