import api from './client';

const get = (url, params) => api.get(url, { params }).then((r) => r.data);
const post = (url, body) => api.post(url, body).then((r) => r.data);
const patch = (url, body) => api.patch(url, body).then((r) => r.data);
const del = (url) => api.delete(url).then((r) => r.data);

export const authApi = {
  me: () => get('/auth/me/'),
  login: (body) => post('/auth/login/', body),
  register: (body) => post('/auth/register/', body),
  logout: () => post('/auth/logout/'),
  changePassword: (body) => post('/auth/change-password/', body),
};
export const departmentsApi = {
  list: (params) => get('/departments/', params),
  create: (b) => post('/departments/', b),
  update: (id, b) => patch(`/departments/${id}/`, b),
  remove: (id) => del(`/departments/${id}/`),
};
export const doctorsApi = {
  list: (params) => get('/doctors/', params),
  get: (id) => get(`/doctors/${id}/`),
  create: (b) => post('/doctors/', b),
  update: (id, b) => patch(`/doctors/${id}/`, b),
  availability: (id, date) => get(`/doctors/${id}/availability/`, { date }),
};
export const schedulesApi = {
  list: (params) => get('/schedules/', params),
  create: (b) => post('/schedules/', b),
  update: (id, b) => patch(`/schedules/${id}/`, b),
  remove: (id) => del(`/schedules/${id}/`),
};
export const timeOffApi = {
  list: (params) => get('/time-off/', params),
  create: (b) => post('/time-off/', b),
  remove: (id) => del(`/time-off/${id}/`),
};
export const patientsApi = {
  me: () => get('/patients/me/'),
  updateMe: (b) => patch('/patients/me/', b),
  list: (params) => get('/patients/', params),
  update: (id, b) => patch(`/patients/${id}/`, b),
};
export const appointmentsApi = {
  list: (params) => get('/appointments/', params),
  get: (id) => get(`/appointments/${id}/`),
  create: (b) => post('/appointments/', b),
  update: (id, b) => patch(`/appointments/${id}/`, b),
  cancel: (id, reason = '') => post(`/appointments/${id}/cancel/`, { reason }),
  reschedule: (id, start_datetime) => post(`/appointments/${id}/reschedule/`, { start_datetime }),
};
export const dashboardApi = {
  patient: () => get('/dashboard/patient/'),
  doctor: () => get('/dashboard/doctor/'),
  admin: () => get('/dashboard/admin/'),
};
export const notificationsApi = {
  list: () => get('/notifications/'),
  read: (id) => post(`/notifications/${id}/read/`),
  readAll: () => post('/notifications/read-all/'),
};
