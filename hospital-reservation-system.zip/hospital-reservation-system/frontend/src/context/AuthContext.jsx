import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authApi } from '../api/services';
import { refreshCsrf } from '../api/client';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export const homeFor = (role) =>
  ({ PATIENT: '/patient', DOCTOR: '/doctor', ADMIN: '/admin' }[role] || '/');

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    authApi.me().then(setUser).catch(() => setUser(null)).finally(() => setLoading(false));
  }, []);

  const login = useCallback(async (creds) => {
    const u = await authApi.login(creds);
    await refreshCsrf(); // Django rotates the CSRF token at login
    setUser(u);
    return u;
  }, []);
  const register = useCallback(async (body) => {
    const u = await authApi.register(body);
    await refreshCsrf();
    setUser(u);
    return u;
  }, []);
  const logout = useCallback(async () => {
    try { await authApi.logout(); } finally { setUser(null); await refreshCsrf().catch(() => {}); }
  }, []);

  const value = useMemo(() => ({ user, loading, login, register, logout, setUser }), [user, loading, login, register, logout]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
