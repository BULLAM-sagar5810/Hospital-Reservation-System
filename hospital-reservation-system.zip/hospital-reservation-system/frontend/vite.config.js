import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// In development the Vite server forwards /api/* to Django, so browser and API share one origin
// (no CORS or cross-site cookie problems while learning).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/api': { target: 'http://127.0.0.1:8000', changeOrigin: false } },
  },
  test: { environment: 'jsdom', globals: true, setupFiles: './src/test/setup.js', css: false },
});
