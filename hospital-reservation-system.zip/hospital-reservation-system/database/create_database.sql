-- Run in MySQL Workbench as the root user. CHANGE THE PASSWORD before running.
CREATE DATABASE IF NOT EXISTS hospital_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'hospital_user'@'localhost' IDENTIFIED BY 'ChangeThisPassword!123';

-- Least privilege: only this database, only what Django needs (migrations need CREATE/ALTER/INDEX/DROP/REFERENCES).
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, DROP, REFERENCES
  ON hospital_db.* TO 'hospital_user'@'localhost';

-- Django's test runner creates a temporary "test_hospital_db". Grant this ONLY on a development machine:
GRANT ALL PRIVILEGES ON `test\_hospital\_db`.* TO 'hospital_user'@'localhost';
FLUSH PRIVILEGES;
