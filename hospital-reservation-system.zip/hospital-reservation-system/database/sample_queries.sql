-- Sample queries for MySQL Workbench. Table names are Django's defaults (app_model).
USE hospital_db;

-- 1. Doctors by department
SELECT d.name AS department, u.name AS doctor, dp.specialization, dp.consultation_fee
FROM doctors_doctorprofile dp
JOIN accounts_user u        ON u.id = dp.user_id
JOIN departments_department d ON d.id = dp.department_id
WHERE dp.is_listed = 1 AND u.is_active = 1
ORDER BY d.name, u.name;

-- 2. Upcoming appointments of one patient (change the e-mail). Times are stored in UTC.
SELECT a.id, du.name AS doctor, a.start_datetime AS start_utc, a.status
FROM appointments_appointment a
JOIN accounts_user pu ON pu.id = a.patient_id
JOIN doctors_doctorprofile dp ON dp.id = a.doctor_id
JOIN accounts_user du ON du.id = dp.user_id
WHERE pu.email = 'patient01@example.test'
  AND a.start_datetime >= UTC_TIMESTAMP()
  AND a.status IN ('PENDING','CONFIRMED')
ORDER BY a.start_datetime;

-- 3. Appointments counted by status
SELECT status, COUNT(*) AS total FROM appointments_appointment GROUP BY status ORDER BY total DESC;

-- 4. One doctor's schedule for one local day (IST = UTC+05:30 -> day starts 18:30 UTC the day before)
SET @doctor_id = 1, @day_start_utc = '2026-11-09 18:30:00';
SELECT a.start_datetime, a.end_datetime, pu.name AS patient, a.status
FROM appointments_appointment a JOIN accounts_user pu ON pu.id = a.patient_id
WHERE a.doctor_id = @doctor_id
  AND a.start_datetime >= @day_start_utc
  AND a.start_datetime <  DATE_ADD(@day_start_utc, INTERVAL 1 DAY)
ORDER BY a.start_datetime;

-- 5. Appointment totals by department
SELECT d.name AS department, COUNT(a.id) AS total
FROM departments_department d
LEFT JOIN doctors_doctorprofile dp ON dp.department_id = d.id
LEFT JOIN appointments_appointment a ON a.doctor_id = dp.id
GROUP BY d.id, d.name ORDER BY total DESC;

-- 6. Cancelled appointments with reasons
SELECT a.id, pu.name AS patient, du.name AS doctor, a.start_datetime, a.cancellation_reason
FROM appointments_appointment a
JOIN accounts_user pu ON pu.id = a.patient_id
JOIN doctors_doctorprofile dp ON dp.id = a.doctor_id
JOIN accounts_user du ON du.id = dp.user_id
WHERE a.status = 'CANCELLED' ORDER BY a.start_datetime DESC;

-- 7. Most frequently booked doctors
SELECT du.name AS doctor, COUNT(*) AS bookings
FROM appointments_appointment a
JOIN doctors_doctorprofile dp ON dp.id = a.doctor_id
JOIN accounts_user du ON du.id = dp.user_id
GROUP BY du.id, du.name ORDER BY bookings DESC LIMIT 5;

-- 8. Prove the double-booking guard: this INSERT of an already active slot fails with error 1062
-- (Duplicate entry ... for key 'uniq_active_slot_per_doctor'). Run only on throw-away data.
-- INSERT INTO appointments_appointment (patient_id, doctor_id, start_datetime, end_datetime, status, active_start, ...)

-- 9. See the indexes Django created
SHOW INDEX FROM appointments_appointment;
