# CareBridge – Hospital Reservation and Management System

A full-stack portfolio project: patients book hospital appointments online, doctors manage their schedules, and administrators manage the hospital – with a React frontend, Django REST API and MySQL database.

> Fictional hospital, fictional data. The application **administers appointments only**; it gives no medical advice or diagnosis.

## Problem statement
Booking by phone causes queues, double bookings and no audit trail. This system lets patients see real, conflict-free slots, and gives staff a single source of truth.

## Features
* **Patient** – register/login, search doctors (name, specialization, department), view profiles, live slot availability, book, reschedule, cancel (with a cancellation window), history, status tracking, profile + password change, notifications.
* **Doctor** – dashboard (today / upcoming), accept/reject requests, mark completed / missed, weekly schedule, leave periods, pause bookings, own profile. Sees only own appointments and only the patient's name.
* **Admin** – statistics (patients, doctors, bookings, cancellations, per-department and top doctors), manage doctors, departments, patient accounts, all appointments, list/hide doctors.
* **Backend rules** – schedule + leave + past + duration checks, transactional booking with row locking, a database unique constraint against double booking, atomic rescheduling, consistent error format, throttling, role-based permissions on every endpoint.

## Technology
React 18, React Router 6, Axios, Vite · Python, Django 5, Django REST Framework, drf-spectacular (Swagger) · MySQL 8 (SQLite fallback for a quick trial) · Vitest + Testing Library, Django test framework.

## Architecture
```
Browser (React SPA) ──/api (JSON, session cookie + CSRF header)──▶ Django REST Framework ──ORM──▶ MySQL
```
`accounts` (custom user, auth, patient profile) · `departments` · `doctors` (profiles, schedules, leave) · `appointments` (bookings, services, notifications) · `dashboard`.
Business logic lives in `backend/appointments/services.py`; views stay thin. Details: [docs/database_design.md](docs/database_design.md).

## Quick start (details in [docs/setup_windows.md](docs/setup_windows.md))
```powershell
# backend
cd backend ; python -m venv venv ; .\venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env        # set DJANGO_SECRET_KEY, DB_PASSWORD (or DB_ENGINE=sqlite)
python manage.py migrate ; python manage.py seed_data ; python manage.py runserver
# frontend (second terminal)
cd frontend ; npm install ; npm run dev     # http://localhost:5173
```
Demo logins (password `Demo@12345`, development only): `admin@hospital.test`, `dr.anita.rao@hospital.test`, `patient01@example.test`.

## Environment variables
See `backend/.env.example` and `frontend/.env.example`. Real `.env` files are git-ignored.

## API
Interactive Swagger UI at `/api/docs/`; written reference in [docs/api_documentation.md](docs/api_documentation.md).

## Testing
```powershell
cd backend ; python manage.py test      # 56 tests (+1 MySQL-only concurrency test)
cd frontend ; npm test                   # 13 tests
```
Manual checklist: [docs/testing_checklist.md](docs/testing_checklist.md).

**What was verified while this project was generated:** all backend tests pass on SQLite; frontend tests and the production build pass; a scripted login → availability → booking → conflict flow ran successfully through the Vite proxy against a live Django server. **Not verified here:** running against a real MySQL server (including the parallel-booking test), real browser clicking, and deployment. Please run the checklist on your machine.

## Security considerations
Django PBKDF2 password hashing · HttpOnly session cookie + CSRF header · role permissions and object-level queryset scoping on every API · server-side validation · ORM only (no string SQL) · throttled login/register/booking · secrets from environment, app refuses to start in production without a key · secure cookies/HSTS/HTTPS redirect when `DEBUG=False` · least-privilege DB user · minimal patient data exposure · fictional seed data.

## Project structure
```
backend/   config/ accounts/ departments/ doctors/ appointments/ dashboard/ manage.py requirements.txt
frontend/  src/{api,components,context,hooks,layouts,pages,routes,utils,test}
database/  create_database.sql  sample_queries.sql
docs/      api_documentation.md database_design.md testing_checklist.md setup_windows.md deployment.md learning_notes.md
```

## Git and GitHub
```powershell
git init
git add .
git status                 # confirm .env is NOT listed
git commit -m "Initial commit: hospital reservation system"
# create an empty repository on github.com, then:
git branch -M main
git remote add origin https://github.com/<your-username>/hospital-reservation-system.git
git push -u origin main
```

## Screenshots
Add your own screenshots to `docs/screenshots/` and link them here after running the app.

## Future improvements
Real e-mail/SMS reminders · doctor-specific appointment types and durations · payments · waiting list · audit log · CI pipeline · Docker setup · E2E tests with Playwright.

## Author
Your Name – your-email@example.com – GitHub/LinkedIn links.
